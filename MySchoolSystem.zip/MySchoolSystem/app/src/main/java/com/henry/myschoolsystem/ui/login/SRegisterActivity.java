package com.henry.myschoolsystem.ui.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.Selection;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.bean.StudentBean;
import com.henry.myschoolsystem.bean.UserBean;
import com.henry.myschoolsystem.utils.CurrentUser;
import com.henry.myschoolsystem.utils.DBUtils;
import com.henry.myschoolsystem.utils.IDUtils;
import com.henry.myschoolsystem.utils.LimitName;
import com.henry.myschoolsystem.utils.MD5Utils;

public class SRegisterActivity extends AppCompatActivity {

    private Button buttonRegister;
    private EditText editTextStudentNum, editTextUserName2, editTextPassword2, editConfirmPassword2;
    private String studentNum, userName2, password2, confirm2;
    private int counter1 = 0, counter2 = 0;  //限制弹窗的次数，防止用户一直不符合规则，弹窗弹个不停

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sregister);
        buttonRegister = findViewById(R.id.buttonRegister2);
        editTextStudentNum = findViewById(R.id.editStudentNum);
        editTextUserName2 = findViewById(R.id.add_username2);
        editTextPassword2 = findViewById(R.id.add_password2);
        editConfirmPassword2 = findViewById(R.id.confirm_password2);

        //修改注册按钮的字体
        Typeface customFont = Typeface.createFromAsset(this.getAssets(), "fonts/Coca-Cola.TTF");
        buttonRegister.setTypeface(customFont);

        nameCntentListener();
        passwordCntentListener();

        /**
         * 注册
         **/
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                studentNum = editTextStudentNum.getText().toString().trim();
                userName2 = editTextUserName2.getText().toString().trim();
                password2 = editTextPassword2.getText().toString().trim();
                confirm2 = editConfirmPassword2.getText().toString().trim();

                StudentBean bean = null;
                //检查数据库中是否有该学号
                bean = getStudentDataByStudentNum(studentNum);
                if (bean == null) {
                    Toast.makeText(SRegisterActivity.this, "该学号不存在，请填写正确的学号！", Toast.LENGTH_SHORT).show();
                } else {
                    if (bean.userName.equals("暂无")) {
                        if (userName2.equals("") || password2.equals("")) {  //如果填写的用户名或密码为空时
                            Toast.makeText(SRegisterActivity.this, "账号或密码为空，请重新填写", Toast.LENGTH_SHORT).show();
                        } else {
                            if (!LimitName.limitName(userName2)) {
                                Toast.makeText(SRegisterActivity.this, "账号仅允许英文字母、数字和-的组合", Toast.LENGTH_SHORT).show();
                            } else {
                                nameCntentListener();
                                passwordCntentListener();
                                if (!password2.equals(confirm2)) {  //两次输入的密码不一致
                                    Toast.makeText(SRegisterActivity.this, "两次输入的密码不一致，请重新输入", Toast.LENGTH_SHORT).show();
                                    editConfirmPassword2.setText(""); //将输入框内容清除
                                    editTextPassword2.setText("");
                                } else {
                                    bean.userName = userName2;
                                    bean.nickName = "快给自己起个昵称叭";
                                    bean.sex = "保密";
                                    bean.qq = "暂无";
                                    bean.wechat = "暂无";
                                    bean.motto = "有点懒吖，啥都没写~";
                                    bean.password = MD5Utils.md5(password2);
                                    //保存到ID对应的表中
                                    insertStudent(studentNum, bean);

                                    Toast.makeText(SRegisterActivity.this, "注册成功!", Toast.LENGTH_SHORT).show();

                                    Intent intent = new Intent(SRegisterActivity.this, SLoginActivity.class);
                                    startActivity(intent);
                                    finish();  //销毁本Activity
                                }
                            }
                        }
                    } else {
                        Toast.makeText(SRegisterActivity.this, "该学号已绑定过用户！", Toast.LENGTH_SHORT).show();
                        editTextPassword2.setText(""); //将输入框内容清除
                        editConfirmPassword2.setText("");
                    }

                }
            }
        });
    }

    /**
     * 监听账号输入框的文字
     **/
    private void nameCntentListener() {
        editTextUserName2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Editable editable = editTextUserName2.getText();
                int len = editable.length();//输入文本的长度
                if (len > 10) {
                    int selEndIndex = Selection.getSelectionEnd(editable);
                    String str = editable.toString();
                    //截取新字符串
                    String newStr = str.substring(0, 10);
                    editTextUserName2.setText(newStr);
                    editable = editTextUserName2.getText();
                    //新字符串长度
                    int newLen = editable.length();
                    //旧光标位置超过新字符串长度
                    if (selEndIndex > newLen) {
                        selEndIndex = editable.length();
                    }
                    //设置新光标的位置
                    Selection.setSelection(editable, selEndIndex);
                    if (counter1 < 3) { //事不过三哈哈哈
                        Toast.makeText(SRegisterActivity.this, "账号最多10位吖！", Toast.LENGTH_SHORT).show();
                        counter1++;
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    /**
     * 监听密码输入框的文字
     **/
    private void passwordCntentListener() {
        editTextPassword2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Editable editable = editTextPassword2.getText();
                int len = editable.length();//输入文本的长度
                if (len > 16) {
                    int selEndIndex = Selection.getSelectionEnd(editable);
                    String str = editable.toString();
                    String newStr = str.substring(0, 16);
                    editTextPassword2.setText(newStr);
                    editable = editTextPassword2.getText();
                    int newLen = editable.length();
                    if (selEndIndex > newLen) {
                        selEndIndex = editable.length();
                    }
                    Selection.setSelection(editable, selEndIndex);
                    if (counter2 < 3) { //事不过三哈哈哈
                        Toast.makeText(SRegisterActivity.this, "密码最多16位吖！", Toast.LENGTH_SHORT).show();
                        counter2++;
                    }
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void insertStudent(String id, StudentBean bean) {
        DBUtils.getInstance(this).updateStudentInfoAll(id, bean);
    }

    private StudentBean getStudentDataByStudentNum(String id) {
        StudentBean bean = DBUtils.getInstance(this).getStudentInfoByID(id);
        return bean;
    }

}
