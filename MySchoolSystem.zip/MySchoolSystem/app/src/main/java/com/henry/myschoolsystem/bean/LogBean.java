package com.henry.myschoolsystem.bean;

public class LogBean {
    public String userID;  //登录的用户ID
    public String userName;  //登录的用户姓名
    public String time;  //log记录的时间
}
