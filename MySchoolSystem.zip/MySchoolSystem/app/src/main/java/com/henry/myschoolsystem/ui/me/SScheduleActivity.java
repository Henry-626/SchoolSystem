package com.henry.myschoolsystem.ui.me;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

import com.henry.myschoolsystem.R;

public class SScheduleActivity extends AppCompatActivity {

    private TextView title, delete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //若当前用户未绑定班级
//        setTheme(R.style.Theme_AppCompat_DayNight_DarkActionBar);
//        setContentView(R.layout.); //加载“空空如也”页面
        setContentView(R.layout.activity_sschedule);

        title = findViewById(R.id.title_sschedule);
        delete = findViewById(R.id.delete_courses);

        //修改标题和删除按钮的字体
        Typeface customFont = Typeface.createFromAsset(this.getAssets(),"fonts/Coca-Cola.TTF");
        title.setTypeface(customFont);
        delete.setTypeface(customFont);
    }
}
