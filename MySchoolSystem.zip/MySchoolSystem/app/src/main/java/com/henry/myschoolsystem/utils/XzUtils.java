package com.henry.myschoolsystem.utils;


public class XzUtils {
    public static int XzSearch(int month, int day) {
        int result = 0;  //不符合下面的要求则为输入不规范，返回0
        switch (month) {
            case 1:
                if (day > 0 && day < 20) result = 1; //摩羯座
                else if (day <= 31) result = 2; //水瓶座
                break;
            case 2:
                if (day > 0 && day < 19) result = 2; //水瓶座
                else if (day <= 29) result = 3; //双鱼座
                break;
            case 3:
                if (day > 0 && day < 21) result = 3; //双鱼座
                else if (day <= 31) result = 4; //白羊座
                break;
            case 4:
                if (day > 0 && day < 20) result = 4; //白羊座
                else if (day < 31) result = 5; //金牛座
                break;
            case 5:
                if (day > 0 && day < 21) result = 5; //金牛座
                else if (day <= 31) result = 6; //双子座
                break;
            case 6:
                if (day > 0 && day < 22) result = 6; //双子座
                else if (day < 31) result = 7; //巨蟹座
                break;
            case 7:
                if (day > 0 && day < 23) result = 7; //巨蟹座
                else if (day <= 31) result = 8; //狮子座
                break;
            case 8:
                if (day > 0 && day < 23) result = 8; //狮子座
                else if (day <= 31) result = 9; //处女座
                break;
            case 9:
                if (day > 0 && day < 23) result = 9; //处女座
                else if (day < 31) result = 10; //天秤座
                break;
            case 10:
                if (day > 0 && day < 24) result = 10; //天秤座
                else if (day <= 31) result = 11; //天蝎座
                break;
            case 11:
                if (day > 0 && day < 23) result = 11; //天蝎座
                else if (day < 31) result = 12; //射手座
                break;
            case 12:
                if (day > 0 && day < 22) result = 12; //射手座
                else if (day <= 31) result = 1; //摩羯座
                break;
            default:
                break;
        }
        return result;
    }
}
