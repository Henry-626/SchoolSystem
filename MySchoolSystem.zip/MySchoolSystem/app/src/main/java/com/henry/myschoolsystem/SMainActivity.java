package com.henry.myschoolsystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.henry.myschoolsystem.bean.LogBean;
import com.henry.myschoolsystem.bean.StudentBean;
import com.henry.myschoolsystem.ui.admin.ClassActivity;
import com.henry.myschoolsystem.utils.CurrentUser;
import com.henry.myschoolsystem.utils.DBUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class SMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_smain);
        BottomNavigationView navView = findViewById(R.id.nav_view);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");// HH:mm:ss
        //获取当前时间
        Date date = new Date(System.currentTimeMillis());
        LogBean bean = new LogBean();
        bean.userID = CurrentUser.getuserID();
        bean.userName = CurrentUser.getRealName();
        bean.time = "登录时间：" + simpleDateFormat.format(date);
        saveLog(bean);
        Toast.makeText(SMainActivity.this, bean.time, Toast.LENGTH_LONG).show();


        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_sluntan, R.id.navigation_sstudy, R.id.navigation_splan, R.id.navigation_sme)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);
    }

    private void saveLog(LogBean logBean) {
        DBUtils.getInstance(this).savaLogInfo(logBean);
    }
}
