package com.henry.myschoolsystem.bean;

public class TeacherBean {
    public String userName;  //账号
    public String realName;  //真实姓名
    public String nickName;  //昵称
    public String ID;  //教师工号
    public String sex;    //性别
    public String qq;  //QQ号
    public String wechat;  //微信号
    public String motto;  //个性签名
    public String phoneNumber;  //手机号
    public String password;  //密码
    public String isHead;  //标记是否是班主任
}
