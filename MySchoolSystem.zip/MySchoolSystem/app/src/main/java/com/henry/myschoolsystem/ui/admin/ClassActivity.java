package com.henry.myschoolsystem.ui.admin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.cursoradapter.widget.SimpleCursorAdapter;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.ui.login.DBOpenHelper;
import com.henry.myschoolsystem.utils.PhoneNumberUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClassActivity extends AppCompatActivity implements View.OnClickListener {

    private List<Map<String, String>> list = new ArrayList<>();
    private ListView listView;
    private Button btn_insert, btn_search;
    private EditText et_ID, et_year, et_name, et_code, et_search, et_dialog_name, et_dialog_head, et_dialog_code;
    private SimpleCursorAdapter simpleCursorAdapter;
    private SQLiteDatabase mDbWriter;
    private SQLiteDatabase mDbReader;
    private DBOpenHelper openHelper;
    private int flag;  //用于区分查询结果的弹窗显示
    private String lastName;  //用于修改信息时判断

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class);

        initView();
        initEvent();

        //单击修改item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, final View view, final int position, long l) {
                View mView = View.inflate(ClassActivity.this, R.layout.dialog_et2_layout, null);       //将放置了三个EditText的布局dialog_et_layout渲染成view对象
                et_dialog_name = (EditText) mView.findViewById(R.id.et_dialog_className);       //要用对应布局的view对象去findViewById获取控件对象
                et_dialog_head = (EditText) mView.findViewById(R.id.et_dialog_classHead);
                et_dialog_code = (EditText) mView.findViewById(R.id.et_dialog_classCode);
                et_dialog_name.setText(((TextView) view.findViewById(R.id.class_name)).getText());   //获取并显示原来的班名
                et_dialog_head.setText(((TextView) view.findViewById(R.id.class_teacher)).getText());       //获取并显示原来的班主任姓名
                lastName = et_dialog_head.getText().toString().trim();
                et_dialog_code.setText(((TextView) view.findViewById(R.id.class_code)).getText());       //获取并显示原来的班级验证码
                new AlertDialog.Builder(ClassActivity.this)
                        .setTitle("修改信息")
                        .setMessage("您是否要修改该班级数据?")
                        .setView(mView)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                String name = et_dialog_name.getText().toString().trim();  //获取修改后的班名
                                String head = et_dialog_head.getText().toString().trim();  //获取修改后的班主任姓名
                                String code = et_dialog_code.getText().toString().trim();  //获取修改后的班级验证码
                                if (name.equals("") || head.equals("") || code.equals("")) {
                                    Toast.makeText(ClassActivity.this, "不能为空呀，请重新填写", Toast.LENGTH_LONG).show();
                                } else {
                                    updateData(position);
                                }
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });


        //长按删除item
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int position, long l) {
                Cursor cursor = simpleCursorAdapter.getCursor();
                cursor.moveToPosition(position);
                String itemID = cursor.getString(cursor.getColumnIndex("classID"));
                String itemYear = cursor.getString(cursor.getColumnIndex("year"));
                String itemName = cursor.getString(cursor.getColumnIndex("className"));
                new AlertDialog.Builder(ClassActivity.this)
                        .setTitle("提示")
                        .setMessage("是否删除该班级：\n" + itemID + "  " + itemYear + " " + itemName)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                deleteData(position);
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
                return true;
            }
        });
    }

    private void initView() {
        listView = (ListView) findViewById(R.id.classListview);
        btn_insert = (Button) findViewById(R.id.btn_insert4);
        btn_search = (Button) findViewById(R.id.btn_search4);
        et_ID = (EditText) findViewById(R.id.et_classID);
        et_name = (EditText) findViewById(R.id.et_className);
        et_year = (EditText) findViewById(R.id.et_classYear);
        et_code = (EditText) findViewById(R.id.et_classCode);
        et_search = (EditText) findViewById(R.id.et_searchClass);


    }

    private void initEvent() {
        btn_insert.setOnClickListener(this);
        btn_search.setOnClickListener(this);

        openHelper = new DBOpenHelper(this);
        mDbWriter = openHelper.getWritableDatabase();
        mDbReader = openHelper.getReadableDatabase();

        simpleCursorAdapter = new SimpleCursorAdapter(ClassActivity.this, R.layout.class_item, null,
                new String[]{"classID", "year", "className", "teacherName_c", "code"}, new int[]{R.id.class_id, R.id.class_year, R.id.class_name, R.id.class_teacher, R.id.class_code}, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

        listView.setAdapter(simpleCursorAdapter);     //给ListView设置适配器
        refreshListview();      //自定义的方法，用于当数据列表改变时刷新ListView

    }

    //刷新数据列表
    public void refreshListview() {
        Cursor cursor = mDbWriter.query(DBOpenHelper.CLASS, null, null, null, null, null, "classID");
        simpleCursorAdapter.changeCursor(cursor);
    }

    //添加班级
    public void insertData() {
        ContentValues cv = new ContentValues();
        cv.put("classID", et_ID.getText().toString().trim());
        cv.put("year", et_year.getText().toString().trim() + "级");
        cv.put("className", et_name.getText().toString().trim());
        cv.put("code", et_code.getText().toString().trim());
        cv.put("teacherName_c", "暂未绑定班主任");
        String ID = et_ID.getText().toString().trim();  //获取输入的ID
        String year = et_year.getText().toString().trim();  //获取输入的年级
        String className = et_name.getText().toString().trim();  //获取输入的班名
        String code = et_code.getText().toString().trim();  //获取输入的验证码
        if (ID.equals("") || className.equals("") || year.equals("") || code.equals("")) {
            Toast.makeText(ClassActivity.this, "填入信息不完整，请重新填写", Toast.LENGTH_SHORT).show();
        } else {
            Cursor cursor = mDbReader.query(DBOpenHelper.CLASS, null, "classID=?", new String[]{ID}, null, null, null);
            if (cursor.getCount() > 0) {
                Toast.makeText(ClassActivity.this, "该班级ID已经被占用啦，请重新填写~", Toast.LENGTH_LONG).show();
            } else {
                mDbWriter.insert(DBOpenHelper.CLASS, null, cv);
                refreshListview();
                et_ID.setText("");   //插入成功清空输入框
                et_year.setText("");
                et_name.setText("");
                et_code.setText("");
            }
        }
    }

    //删除班级
    public void deleteData(int position) {
        Cursor cursor = simpleCursorAdapter.getCursor();
        cursor.moveToPosition(position);
        String itemID = cursor.getString(cursor.getColumnIndex("classID"));
        ContentValues cv = new ContentValues();
        cv.put("classID_u", "班级未绑定");
        mDbWriter.update(DBOpenHelper.USER_INFO, cv, "classID_u=?", new String[]{"班级ID：" + itemID});  //同时修改班主任的ID为初始状态
        mDbWriter.delete(DBOpenHelper.CLASS, "classID=?", new String[]{itemID});
        refreshListview();
    }

    //修改班级
    public void updateData(int position) {
        Cursor cursor = simpleCursorAdapter.getCursor();
        cursor.moveToPosition(position);
        String itemID = cursor.getString(cursor.getColumnIndex("classID"));
        String name = et_dialog_name.getText().toString().trim();
        String head = et_dialog_head.getText().toString().trim();  //若未绑定则输入的是班主任的ID
        String code = et_dialog_code.getText().toString().trim();

        if (lastName.equals("暂未绑定班主任")) { //若班级原先是未绑定班主任的状态
            Cursor cursor1 = mDbReader.query(DBOpenHelper.USER_INFO, null, "identity = 0 and userID=?", new String[]{head}, null, null, null);
            if (cursor1.getCount() > 0) {
                while (cursor1.moveToNext()) {     //遍历
                    String searchID = cursor1.getString(cursor1.getColumnIndex("classID_u"));  //查看该老师的classID是否已绑定
                    String searchName = cursor1.getString(cursor1.getColumnIndex("realName_u"));
                    if (searchID.equals("班级未绑定")) {
                        ContentValues mContentValues = new ContentValues();
                        mContentValues.put("className", name);
                        mContentValues.put("teacherID_c", head);
                        mContentValues.put("teacherName_c", "班主任：" + searchName);
                        mContentValues.put("code", code);

                        ContentValues tContentValues = new ContentValues();
                        tContentValues.put("classID_u", "班级ID：" + itemID);

                        mDbWriter.update(DBOpenHelper.CLASS, mContentValues, "classID=?", new String[]{itemID});
                        mDbWriter.update(DBOpenHelper.USER_INFO, tContentValues, "userID=?", new String[]{head});  //同步更新班主任的班级ID
                        Toast.makeText(ClassActivity.this, "修改成功~", Toast.LENGTH_SHORT).show();
                        refreshListview();
                    } else {
                        Toast.makeText(ClassActivity.this, "该班主任已经绑定了班级啦", Toast.LENGTH_SHORT).show();
                    }
                }
                cursor1.close();
            } else {
                if (head.equals("暂未绑定班主任")) {  //只修改了班名或验证码
                    ContentValues mContentValues = new ContentValues();
                    mContentValues.put("className", name);
                    mContentValues.put("code", code);
                    mDbWriter.update(DBOpenHelper.CLASS, mContentValues, "classID=?", new String[]{itemID});
                    Toast.makeText(ClassActivity.this, "修改成功~", Toast.LENGTH_SHORT).show();
                    refreshListview();
                } else {
                    Toast.makeText(ClassActivity.this, "没有该班主任，请先前往添加~", Toast.LENGTH_LONG).show();
                }
            }
        } else {  //该班级原来已经绑定了班主任，则不可修改
            Toast.makeText(ClassActivity.this, "班主任绑定后就不可修改啦", Toast.LENGTH_LONG).show();
        }

    }

    //查询班级
    public void searchData() {
        String input = et_search.getText().toString().trim();
        Cursor cursor = mDbReader.query(DBOpenHelper.CLASS, null, "className=?", new String[]{input}, null, null, null);
        if (cursor.getCount() > 0) {
            list.clear();        //清空List
            while (cursor.moveToNext()) {     //游标总是在查询到的上一行
                Map<String, String> map = new HashMap<>();
                String searchID = cursor.getString(cursor.getColumnIndex("classID"));
                String searchYear = cursor.getString(cursor.getColumnIndex("year"));
                String searchHead = cursor.getString(cursor.getColumnIndex("teacherName_c"));
                String searchCode = cursor.getString(cursor.getColumnIndex("code"));
                map.put("tv1", "ID：" + searchID);
                map.put("tv2", "年级及班级名：" + searchYear + input);
                map.put("tv3", "班主任：" + searchHead);
                map.put("tv4", "加班验证码：" + searchCode);
//                Toast.makeText(StudentActivity.this, "有的", Toast.LENGTH_SHORT).show();
                list.add(map);
                flag = 1;
            }
            cursor.close();
        } else {
            list.clear();  //清空List
            Map<String, String> map = new HashMap<>();
            map.put("null", "查询结果为空，请确认您输入的班名是否正确");
//            Toast.makeText(StudentActivity.this, "没有", Toast.LENGTH_SHORT).show();
            list.add(map);
            flag = 0;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            //点击添加按钮
            case R.id.btn_insert4:
                insertData();
                break;
            //点击查询按钮
            case R.id.btn_search4:
                searchData();
                if (flag == 1) {
                    new AlertDialog.Builder(ClassActivity.this)
                            .setTitle("查询结果")
                            .setAdapter(new SimpleAdapter(ClassActivity.this, list, R.layout.dialog_tv2_layout, new String[]{"tv1", "tv2", "tv3", "tv4"}, new int[]{R.id.tv21_dialog, R.id.tv22_dialog, R.id.tv23_dialog, R.id.tv24_dialog}), null)
                            .setPositiveButton("确定", null)
                            .show();
                } else {
                    android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(ClassActivity.this);
                    final android.app.AlertDialog dialog = builder.create();
                    final View dialogView = View.inflate(ClassActivity.this, R.layout.custom_dialog_layout, null);
                    //设置对话框布局
                    dialog.setView(dialogView);
                    dialog.show();
                    dialog.getWindow().setBackgroundDrawable(null);
                    final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_ok);
                    btnCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });
                }
                break;

        }
    }

}
