package com.henry.myschoolsystem.bean;

public class ClassBean {
    public String classID;  //班级ID
    public String className;  //班级名
    public String year;  //班级所属年级
    public String studentID;  //学生ID
    public String teacherID;  //班主任ID
    public String teacherName;  //班主任姓名
    public String code;  //加入班级所需验证码
}
