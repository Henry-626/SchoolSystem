package com.henry.myschoolsystem.utils;

/**
 * 将需要用到多次的当前登录的账号信息保存为全局变量
 */
public class CurrentUser {
    private static String userName;
    private static String nickName;
    private static String userID;
    private static String realName;
    private static String isHead;

    public static String getUserName() {
        return userName;
    }

    public static void setUserName(String s) {
        CurrentUser.userName = s;
    }

    public static String getNickName() {
        return nickName;
    }

    public static void setNickName(String s) {
        CurrentUser.nickName = s;
    }

    public static String getuserID() {
        return userID;
    }

    public static void setUserID(String id) {
        CurrentUser.userID = id;
    }

    public static String getRealName() {
        return realName;
    }

    public static void setRealName(String s) {
        CurrentUser.realName = s;
    }

    public static String getIsHead() {
        return isHead;
    }

    public static void setIsHead(String s) {
        CurrentUser.isHead = s;
    }
}
