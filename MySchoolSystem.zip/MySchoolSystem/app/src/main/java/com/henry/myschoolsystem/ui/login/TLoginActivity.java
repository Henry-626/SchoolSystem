package com.henry.myschoolsystem.ui.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.Selection;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.TMainActivity;
import com.henry.myschoolsystem.bean.TeacherBean;
import com.henry.myschoolsystem.utils.CurrentUser;
import com.henry.myschoolsystem.utils.DBUtils;
import com.henry.myschoolsystem.utils.MD5Utils;

public class TLoginActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;
    private Button btn_Save, btn_Login;
    private TextView tv_teacher, btn_forget;
    private int counter1 = 0, counter2 = 0;  //限制弹窗的次数，防止用户一直不符合规则，弹窗弹个不停

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tlogin);

        usernameEditText = findViewById(R.id.login_username);           //获取登录账户的编辑框
        passwordEditText = findViewById(R.id.login_password);  //获取密码的编辑框
        btn_Save = findViewById(R.id.register);      //获取注册按钮
        btn_Login = findViewById(R.id.login);     //获取登录按钮
        btn_forget = findViewById(R.id.forget);   //获取忘记密码
        tv_teacher = findViewById(R.id.tv_teacher);   //获取教师登录的TextView

        //修改以下三个组件的字体
        Typeface customFont = Typeface.createFromAsset(this.getAssets(),"fonts/Coca-Cola.TTF");
        tv_teacher.setTypeface(customFont);
        btn_Save.setTypeface(customFont);
        btn_Login.setTypeface(customFont);

        nameCntentListener();
        passwordCntentListener();

        //登录
        btn_Login.setOnClickListener(new View.OnClickListener() {  //单击登录按钮查看是否有该用户以及密码是否正确
            @Override
            public void onClick(View v) {
                String teacher = usernameEditText.getText().toString().trim();  //获取输入的登录名
                TeacherBean teacherBean = null;
                teacherBean = getTeacherData(teacher);
                if (teacherBean == null) {
                    Toast.makeText(TLoginActivity.this, "该账号不存在，请重新输入或注册！", Toast.LENGTH_SHORT).show();
                } else {
                    String passwordIn = passwordEditText.getText().toString().trim(); //获取输入的密码
                    if (teacherBean.password.equals(MD5Utils.md5(passwordIn))) {   //只是比较内容，不能用==
                        Toast.makeText(TLoginActivity.this, "登录成功！" + teacher + "，欢迎您~", Toast.LENGTH_SHORT).show();

                        CurrentUser.setUserID(teacherBean.ID); //将登录成功的当前登录用户的关键信息以及是否是班主任存为全局变量
                        CurrentUser.setUserName(teacher);
                        CurrentUser.setIsHead(teacherBean.isHead);
                        CurrentUser.setRealName(teacherBean.realName);
                        CurrentUser.setNickName(teacherBean.nickName);
                        Intent intent = new Intent(TLoginActivity.this, TMainActivity.class);  //登录成功跳转教师主界面
                        startActivity(intent);
                        finish();
                    } else {
                        if (passwordIn.equals("")) {
                            Toast.makeText(TLoginActivity.this, "密码不能为空哦！", Toast.LENGTH_SHORT).show();
                        } else {
                            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(TLoginActivity.this);
                            final android.app.AlertDialog dialog = builder.create();
                            final View dialogView = View.inflate(TLoginActivity.this, R.layout.dialog_forget, null);
                            //设置对话框布局
                            dialog.setView(dialogView);
                            dialog.show();
                            dialog.getWindow().setBackgroundDrawable(null);
                            final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_Login_cancel);
                            final Button btnForget = (Button) dialogView.findViewById(R.id.btn_Login_forget);
                            btnForget.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                    Intent intent = new Intent(TLoginActivity.this, TForgetActivity.class);  //跳转至忘记密码界面
                                    startActivity(intent);
                                    finish();
                                }
                            });
                            btnCancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Toast.makeText(TLoginActivity.this, "您选择了重新输入，输入要细心哈", Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                }
                            });
                        }
                    }
                }
            }
        });
        //注册
        btn_Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TLoginActivity.this, TRegisterActivity.class);  //跳转至注册页面
                startActivity(intent);
                finish();
            }
        });
        //忘记密码
        btn_forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TLoginActivity.this, SForgetActivity.class);  //跳转至教师端忘记页面
                startActivity(intent);
                finish();
            }
        });
    }

    /**
     * 监听账号输入框的文字
     **/
    private void nameCntentListener() {
        usernameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Editable editable = usernameEditText.getText();
                int len = editable.length();//输入文本的长度
                if (len > 10) {
                    int selEndIndex = Selection.getSelectionEnd(editable);
                    String str = editable.toString();
                    //截取新字符串
                    String newStr = str.substring(0, 10);
                    usernameEditText.setText(newStr);
                    editable = usernameEditText.getText();
                    //新字符串长度
                    int newLen = editable.length();
                    //旧光标位置超过新字符串长度
                    if (selEndIndex > newLen) {
                        selEndIndex = editable.length();
                    }
                    //设置新光标的位置
                    Selection.setSelection(editable, selEndIndex);
                    if(counter1 < 3) { //事不过三哈哈哈
                        Toast.makeText(TLoginActivity.this, "账号最多10位吖！", Toast.LENGTH_SHORT).show();
                        counter1++;
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    /**
     * 监听密码输入框的文字
     **/
    private void passwordCntentListener() {
        passwordEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Editable editable = passwordEditText.getText();
                int len = editable.length();//输入文本的长度
                if (len > 16) {
                    int selEndIndex = Selection.getSelectionEnd(editable);
                    String str = editable.toString();
                    String newStr = str.substring(0, 16);
                    passwordEditText.setText(newStr);
                    editable = passwordEditText.getText();
                    int newLen = editable.length();
                    if (selEndIndex > newLen) {
                        selEndIndex = editable.length();
                    }
                    Selection.setSelection(editable, selEndIndex);
                    if(counter2 < 3) { //事不过三哈哈哈
                        Toast.makeText(TLoginActivity.this, "密码最多16位吖！", Toast.LENGTH_SHORT).show();
                        counter2++;
                    }
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private TeacherBean getTeacherData(String key) {
        TeacherBean bean = DBUtils.getInstance(this).getTeacherInfo(key);
        return bean;
    }
}
