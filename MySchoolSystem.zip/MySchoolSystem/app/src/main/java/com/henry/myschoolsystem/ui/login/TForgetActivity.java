package com.henry.myschoolsystem.ui.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.bean.StudentBean;
import com.henry.myschoolsystem.bean.TeacherBean;
import com.henry.myschoolsystem.utils.DBUtils;
import com.henry.myschoolsystem.utils.MD5Utils;
import com.henry.myschoolsystem.utils.PhoneNumberUtils;

import org.json.JSONException;
import org.json.JSONObject;

import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;

public class TForgetActivity extends AppCompatActivity {

    private EditText editTextPhoneNum, editTextCode, editTextPassword, editTextConfirm;
    private Button btn_code, btn_reset;
    private String phoneNum, code, password, confirm;
    private EventHandler eh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tforget);
        editTextCode = findViewById(R.id.tforget_Code);
        editTextPhoneNum = findViewById(R.id.tforget_phoneNumber);
        editTextConfirm = findViewById(R.id.tforget_confirm);
        editTextPassword = findViewById(R.id.tforget_password);
        btn_code = findViewById(R.id.tforget_buttonCode);  //获取验证码按钮
        btn_reset = findViewById(R.id.reset_password_t);   //获取重置密码按钮

        //修改以下按钮的字体
        Typeface customFont = Typeface.createFromAsset(this.getAssets(), "fonts/Coca-Cola.TTF");
        btn_code.setTypeface(customFont);
        btn_reset.setTypeface(customFont);

        eh = new EventHandler() {
            @Override
            public void afterEvent(int event, int result, Object data) {
                if (result == SMSSDK.RESULT_COMPLETE) {
                    //回调完成
                    if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) {
                        //提交验证码成功
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                password = editTextPassword.getText().toString().trim();
                                phoneNum = editTextPhoneNum.getText().toString().trim();
                                confirm = editTextConfirm.getText().toString().trim();

                                //如果填写的密码或确认密码为空时
                                if (confirm.equals("") || password.equals("")) {
                                    Toast.makeText(TForgetActivity.this, "请将输入框填写完整！", Toast.LENGTH_SHORT).show();
                                } else {
                                    if (password.equals(confirm)) {
                                        //将新密码替换到数据库
                                        updateTeacher("password_t", MD5Utils.md5(confirm), phoneNum);  //别忘了MD5加密
                                        Toast.makeText(TForgetActivity.this, "重置密码成功!", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(TForgetActivity.this, TLoginActivity.class);
                                        startActivity(intent);
                                        finish();  //销毁本Activity
                                    } else {
                                        Toast.makeText(TForgetActivity.this, "两次密码不一致！需重新获取验证码然后重填", Toast.LENGTH_SHORT).show();
                                        editTextConfirm.setText(""); //将输入框内容清除
                                        editTextPassword.setText("");
                                        editTextCode.setText("");
                                    }
                                }
                            }
                        });
                    } else if (event == SMSSDK.EVENT_GET_VOICE_VERIFICATION_CODE) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(TForgetActivity.this, "语音验证发送", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE) {
                        //获取验证码成功
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(TForgetActivity.this, "验证码已发送", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else if (event == SMSSDK.EVENT_GET_SUPPORTED_COUNTRIES) {
                        Log.i("test", "test");
                    }
                } else {
                    ((Throwable) data).printStackTrace();
                    Throwable throwable = (Throwable) data;
                    throwable.printStackTrace();
                    Log.i("1234", throwable.toString());
                    try {
                        JSONObject obj = new JSONObject(throwable.getMessage());
                        final String des = obj.optString("detail");
                        if (!TextUtils.isEmpty(des)) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(TForgetActivity.this, des, Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        //注册一个事件回调监听，用于处理SMSSDK接口请求的结果
        SMSSDK.registerEventHandler(eh);
        btn_code.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phoneNum = editTextPhoneNum.getText().toString();
                if (!phoneNum.isEmpty()) {
                    if (PhoneNumberUtils.checkTel(phoneNum)) { //利用正则表达式获取检验手机号
                        TeacherBean bean = null;
                        //检查数据库中该手机号是否已经被绑定
                        bean = getTeacherDataByPhoneNum(phoneNum);
                        if (bean == null) {
                            Toast.makeText(TForgetActivity.this, "该手机号未绑定过教师用户，请重新填写！", Toast.LENGTH_SHORT).show();
                            editTextPhoneNum.setText(""); //将输入框内容清除
                        } else {
                            if (bean.password.equals("暂无")) {
                                Toast.makeText(TForgetActivity.this, "该教师还未注册过哦！不能修改密码~", Toast.LENGTH_SHORT).show();
                                editTextConfirm.setText(""); //将输入框内容清除
                                editTextPassword.setText("");
                                editTextCode.setText("");
                            } else {
                                // 获取验证码
                                SMSSDK.getVerificationCode("86", phoneNum);
                            }
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "请输入有效的手机号", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "请输入手机号", Toast.LENGTH_SHORT).show();
                    return;
                }
                phoneNum = editTextPhoneNum.getText().toString();
            }
        });
        btn_reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                code = editTextCode.getText().toString();
                if (!code.isEmpty()) {
                    //提交验证码
                    SMSSDK.submitVerificationCode("86", phoneNum, code);
                } else {
                    Toast.makeText(getApplicationContext(), "请输入验证码", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });
    }

    private void updateTeacher(String key, String value, String phone) {
        DBUtils.getInstance(this).updateTeacherInfoByPhone(key, value, phone);
    }

    private TeacherBean getTeacherDataByPhoneNum(String phone) {
        TeacherBean bean = DBUtils.getInstance(this).getTeacherInfoByPhoneNum(phone);
        return bean;
    }

    // 使用完EventHandler需注销，否则可能出现内存泄漏
    @Override
    protected void onDestroy() {
        super.onDestroy();
        SMSSDK.unregisterEventHandler(eh);
    }
}
