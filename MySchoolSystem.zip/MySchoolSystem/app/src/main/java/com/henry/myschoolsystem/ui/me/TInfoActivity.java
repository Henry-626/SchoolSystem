package com.henry.myschoolsystem.ui.me;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.bean.ClassBean;
import com.henry.myschoolsystem.bean.StudentBean;
import com.henry.myschoolsystem.bean.TeacherBean;
import com.henry.myschoolsystem.utils.CurrentUser;
import com.henry.myschoolsystem.utils.DBUtils;

public class TInfoActivity extends AppCompatActivity {

    private TextView tv_id, tv_userName, tv_realName, tv_nickName, tv_sex, tv_class, tv_qq, tv_wechat, tv_motto, tv_phoneNumber;
    private ImageButton ib_nickName, ib_sex, ib_qq, ib_wechat, ib_motto, ib_phoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tinfo);

        tv_id = findViewById(R.id.tInfo_ID);
        tv_userName = findViewById(R.id.tInfo_username);
        tv_realName = findViewById(R.id.tInfo_realName);
        tv_nickName = findViewById(R.id.tInfo_nickname);
        tv_sex = findViewById(R.id.tInfo_sex);
        tv_class = findViewById(R.id.tInfo_class);
        tv_qq = findViewById(R.id.tInfo_qq);
        tv_wechat = findViewById(R.id.tInfo_wechat);
        tv_phoneNumber = findViewById(R.id.tInfo_phone);
        tv_motto = findViewById(R.id.tInfo_motto);

        ib_nickName = findViewById(R.id.tEditButton1);
        ib_sex = findViewById(R.id.tEditButton2);
        ib_qq = findViewById(R.id.tEditButton4);
        ib_wechat = findViewById(R.id.tEditButton5);
        ib_phoneNumber = findViewById(R.id.tEditButton6);
        ib_motto = findViewById(R.id.tEditButton7);

        //设置默认显示的值
        tv_id.setText(CurrentUser.getuserID());
        tv_userName.setText(CurrentUser.getUserName());
        tv_realName.setText(CurrentUser.getRealName());

        TeacherBean teacherBean = getTeacherDataByTeacherNum(CurrentUser.getuserID());
        tv_nickName.setText(teacherBean.nickName);
        tv_sex.setText(teacherBean.sex);
        tv_qq.setText(teacherBean.qq);
        tv_wechat.setText(teacherBean.wechat);
        tv_phoneNumber.setText(teacherBean.phoneNumber);
        tv_motto.setText(teacherBean.motto);

        if (teacherBean.isHead.equals("0")) {
            tv_class.setText("您不是班主任吖");
        } else {
            ClassBean classBean = getClassDataByTeacherID(teacherBean.ID);
            if (classBean != null) {
                tv_class.setText(classBean.year + classBean.className);
            } else {
                tv_class.setText("暂未绑定班级");
            }
        }

    }

    private TeacherBean getTeacherDataByTeacherNum(String id) {
        TeacherBean bean = DBUtils.getInstance(this).getTeacherInfoByID(id);
        return bean;
    }

    //通过班主任ID获取相应班级信息
    private ClassBean getClassDataByTeacherID(String id) {
        ClassBean bean = DBUtils.getInstance(this).getClassDataByTeacherID(id);
        return bean;
    }
}
