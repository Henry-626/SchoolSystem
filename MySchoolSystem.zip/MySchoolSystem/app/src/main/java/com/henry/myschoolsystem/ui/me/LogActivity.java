package com.henry.myschoolsystem.ui.me;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.cursoradapter.widget.SimpleCursorAdapter;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.ui.admin.StudentActivity;
import com.henry.myschoolsystem.ui.login.DBOpenHelper;
import com.henry.myschoolsystem.utils.CurrentUser;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class LogActivity extends AppCompatActivity {

    private List<Map<String, String>> list = new ArrayList<>();
    private ListView listView;
    private SimpleCursorAdapter simpleCursorAdapter;
    private SQLiteDatabase mDbWriter;
    private DBOpenHelper openHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log);

        initView();
        initEvent();
    }
    private void initView() {
        listView = (ListView) findViewById(R.id.logListView);
    }

    private void initEvent() {

        openHelper = new DBOpenHelper(this);
        mDbWriter = openHelper.getWritableDatabase();

        simpleCursorAdapter = new SimpleCursorAdapter(LogActivity.this, R.layout.log_item, null,
                new String[]{"userID_l", "userName_l", "logContent"}, new int[]{R.id.log_user_id, R.id.log_user_name, R.id.log_user_time}, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

        listView.setAdapter(simpleCursorAdapter);     //给ListView设置适配器
        refreshListview();      //自定义的方法，用于当数据列表改变时刷新ListView

    }
    //刷新数据列表
    public void refreshListview() {
        Cursor cursor = mDbWriter.query(DBOpenHelper.LOG, null, null,null, null, null, null);
        simpleCursorAdapter.changeCursor(cursor);
    }
}
