package com.henry.myschoolsystem.ui.me;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.TextView;

import com.henry.myschoolsystem.R;

public class TScheduleActivity extends AppCompatActivity {
    private TextView title, delete;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tschedule);

        title = findViewById(R.id.title_tschedule);
        delete = findViewById(R.id.delete_courses_teacher);

        //修改标题和删除按钮的字体
        Typeface customFont = Typeface.createFromAsset(this.getAssets(),"fonts/Coca-Cola.TTF");
        title.setTypeface(customFont);
        delete.setTypeface(customFont);
    }
}
