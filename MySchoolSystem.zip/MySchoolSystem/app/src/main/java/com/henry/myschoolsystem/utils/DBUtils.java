package com.henry.myschoolsystem.utils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.henry.myschoolsystem.bean.ClassBean;
import com.henry.myschoolsystem.bean.LogBean;
import com.henry.myschoolsystem.bean.StudentBean;
import com.henry.myschoolsystem.bean.TeacherBean;
import com.henry.myschoolsystem.bean.UserBean;
import com.henry.myschoolsystem.ui.login.DBOpenHelper;

public class DBUtils {
    private static DBUtils instance = null;
    private static DBOpenHelper dbHelper;
    private static SQLiteDatabase db;

    /**
     * 构造方法，只有当类被实例化时候调用
     * 实例化DBOpenHelper类，从中得到一个可读写的数据库
     **/
    public DBUtils(Context context) {
        dbHelper = new DBOpenHelper(context);
        db = dbHelper.getWritableDatabase();
    }

    /**
     * 得到这个类的实例
     **/
    public static DBUtils getInstance(Context context) {
        if (instance == null) {
            instance = new DBUtils(context);
        }
        return instance;
    }

//    /**
//     * 保存教师资料信息
//     **/
//    public void saveTeacherInfo(TeacherBean teacherBean) {
//        ContentValues cv = new ContentValues();
//        cv.put("userName_t", teacherBean.userName);
//        cv.put("realName_t", teacherBean.realName);
//        cv.put("nickName_t", teacherBean.nickName);
//        cv.put("teacherID", teacherBean.ID);
//        cv.put("isHead_t", teacherBean.isHead);
//        cv.put("sex_t", teacherBean.sex);
//        cv.put("qq_t", teacherBean.qq);
//        cv.put("wechat_t",teacherBean.wechat);
//        cv.put("motto_t",teacherBean.motto);
//        cv.put("phoneNumber_t",teacherBean.phoneNumber);
//        cv.put("password_t",teacherBean.password);
//        db.insert(DBOpenHelper.TEACHER_INFO, null, cv);
//    }
//
//    /**
//     * 保存学生资料信息
//     **/
//    public void saveStudentInfo(StudentBean studentBean) {
//        ContentValues cv = new ContentValues();
//        cv.put("userName_s", studentBean.userName);
//        cv.put("realName_s",studentBean.realName);
//        cv.put("nickName_s", studentBean.nickName);
//        cv.put("sex_s", studentBean.sex);
//        cv.put("qq_s", studentBean.qq);
//        cv.put("wechat_s",studentBean.wechat);
//        cv.put("motto_s",studentBean.motto);
//        cv.put("phoneNumber_s",studentBean.phoneNumber);
//        cv.put("password_s",studentBean.password);
//        db.insert(DBOpenHelper.STUDENT_INFO, null, cv);
//    }
//
    /**
     * 给班级添加学生信息（在class表中）
     **/
    public void saveStudentInfo(ClassBean classBean) {
        ContentValues cv = new ContentValues();
        cv.put("classID",classBean.classID);
        cv.put("className",classBean.className);
        cv.put("year",classBean.year);
        cv.put("studentID_c",classBean.studentID);
        cv.put("teacherID_c",classBean.teacherID);
        cv.put("teacherName_c",classBean.teacherName);
        cv.put("code",classBean.code);
        db.insert(DBOpenHelper.CLASS, null, cv);
    }

    /**
     * 保存日志信息
     **/
    public void savaLogInfo(LogBean logBean) {
        ContentValues cv = new ContentValues();
        cv.put("userID_l",logBean.userID);
        cv.put("userName_l",logBean.userName);
        cv.put("logContent",logBean.time);
        db.insert(DBOpenHelper.LOG, null, cv);
    }

//  ---------------------------------------------------------------------------------------------
    /**
     * 通过学号获取班级信息（学生个人信息页面用到）
     **/
    public ClassBean getClassInfoByStudentID(String id) {
        String sql = "SELECT * FROM " + DBOpenHelper.CLASS + " WHERE studentID_c=?";
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        ClassBean classBean = null;
        while (cursor.moveToNext()) {
            classBean = new ClassBean();
            classBean.classID = cursor.getString(cursor.getColumnIndex("classID"));
            classBean.className = cursor.getString(cursor.getColumnIndex("className"));
            classBean.year = cursor.getString(cursor.getColumnIndex("year"));
            classBean.studentID = cursor.getString(cursor.getColumnIndex("studentID_c"));
            classBean.teacherID = cursor.getString(cursor.getColumnIndex("teacherID_c"));
            classBean.teacherName = cursor.getString(cursor.getColumnIndex("teacherName_c"));
            classBean.code = cursor.getString(cursor.getColumnIndex("code"));
        }
        cursor.close();
        return classBean;
    }

    /**
     * 通过工号获取班级信息（教师个人信息页面用到）
     **/
    public ClassBean getClassDataByTeacherID(String id) {
        String sql = "SELECT * FROM " + DBOpenHelper.CLASS + " WHERE teacherID_c=?";
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        ClassBean classBean = null;
        while (cursor.moveToNext()) {
            classBean = new ClassBean();
            classBean.classID = cursor.getString(cursor.getColumnIndex("classID"));
            classBean.className = cursor.getString(cursor.getColumnIndex("className"));
            classBean.year = cursor.getString(cursor.getColumnIndex("year"));
            classBean.studentID = cursor.getString(cursor.getColumnIndex("studentID_c"));
            classBean.teacherID = cursor.getString(cursor.getColumnIndex("teacherID_c"));
            classBean.teacherName = cursor.getString(cursor.getColumnIndex("teacherName_c"));
            classBean.code = cursor.getString(cursor.getColumnIndex("code"));
        }
        cursor.close();
        return classBean;
    }

    /**
     * 通过班级ID获取班级信息
     **/
    public ClassBean getClassInfoByID(String id) {
        String sql = "SELECT * FROM " + DBOpenHelper.CLASS + " WHERE classID=?";
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        ClassBean classBean = null;
        while (cursor.moveToNext()) {
            classBean = new ClassBean();
            classBean.classID = cursor.getString(cursor.getColumnIndex("classID"));
            classBean.className = cursor.getString(cursor.getColumnIndex("className"));
            classBean.year = cursor.getString(cursor.getColumnIndex("year"));
            classBean.studentID = cursor.getString(cursor.getColumnIndex("studentID_c"));
            classBean.teacherID = cursor.getString(cursor.getColumnIndex("teacherID_c"));
            classBean.teacherName = cursor.getString(cursor.getColumnIndex("teacherName_c"));
            classBean.code = cursor.getString(cursor.getColumnIndex("code"));
        }
        cursor.close();
        return classBean;
    }


    /**
     * 通过工号获取教师资料信息
     **/
    public TeacherBean getTeacherInfoByID(String id) {
        String sql = "SELECT * FROM " + DBOpenHelper.TEACHER_INFO + " WHERE teacherID=?";
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        TeacherBean teacherBean = null;
        while (cursor.moveToNext()) {
            teacherBean = new TeacherBean();
            //将对应用户名的所有数据从表中动态赋值给bean
            teacherBean.userName = cursor.getString(cursor.getColumnIndex("userName_t"));
            teacherBean.realName = cursor.getString(cursor.getColumnIndex("realName_t"));
            teacherBean.nickName = cursor.getString(cursor.getColumnIndex("nickName_t"));
            teacherBean.ID = cursor.getString(cursor.getColumnIndex("teacherID"));
            teacherBean.sex = cursor.getString(cursor.getColumnIndex("sex_t"));
            teacherBean.qq = cursor.getString(cursor.getColumnIndex("qq_t"));
            teacherBean.wechat = cursor.getString(cursor.getColumnIndex("wechat_t"));
            teacherBean.motto = cursor.getString(cursor.getColumnIndex("motto_t"));
            teacherBean.phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber_t"));
            teacherBean.password = cursor.getString(cursor.getColumnIndex("password_t"));
            teacherBean.isHead = cursor.getString(cursor.getColumnIndex("isHead_t"));
        }
        cursor.close();
        return teacherBean;
    }
    /**
     * 通过账号获取教师资料信息
     **/
    public TeacherBean getTeacherInfo(String teacherName) {
        String sql = "SELECT * FROM " + DBOpenHelper.TEACHER_INFO + " WHERE userName_t=?";
        Cursor cursor = db.rawQuery(sql, new String[]{teacherName});
        TeacherBean teacherBean = null;
        while (cursor.moveToNext()) {
            teacherBean = new TeacherBean();
            //将对应用户名的所有数据从表中动态赋值给bean
            teacherBean.userName = cursor.getString(cursor.getColumnIndex("userName_t"));
            teacherBean.realName = cursor.getString(cursor.getColumnIndex("realName_t"));
            teacherBean.nickName = cursor.getString(cursor.getColumnIndex("nickName_t"));
            teacherBean.ID = cursor.getString(cursor.getColumnIndex("teacherID"));
            teacherBean.sex = cursor.getString(cursor.getColumnIndex("sex_t"));
            teacherBean.qq = cursor.getString(cursor.getColumnIndex("qq_t"));
            teacherBean.wechat = cursor.getString(cursor.getColumnIndex("wechat_t"));
            teacherBean.motto = cursor.getString(cursor.getColumnIndex("motto_t"));
            teacherBean.phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber_t"));
            teacherBean.password = cursor.getString(cursor.getColumnIndex("password_t"));
            teacherBean.isHead = cursor.getString(cursor.getColumnIndex("isHead_t"));
        }
        cursor.close();
        return teacherBean;
    }
    /**
     * 通过手机号获取教师资料信息
     **/
    public TeacherBean getTeacherInfoByPhoneNum(String phone) {
        String sql = "SELECT * FROM " + DBOpenHelper.TEACHER_INFO + " WHERE phoneNumber_t=?";
        Cursor cursor = db.rawQuery(sql, new String[]{phone});
        TeacherBean teacherBean = null;
        while (cursor.moveToNext()) {
            teacherBean = new TeacherBean();
            //将对应用户名的所有数据从表中动态赋值给bean
            teacherBean.userName = cursor.getString(cursor.getColumnIndex("userName_t"));
            teacherBean.realName = cursor.getString(cursor.getColumnIndex("realName_t"));
            teacherBean.nickName = cursor.getString(cursor.getColumnIndex("nickName_t"));
            teacherBean.ID = cursor.getString(cursor.getColumnIndex("teacherID"));
            teacherBean.sex = cursor.getString(cursor.getColumnIndex("sex_t"));
            teacherBean.qq = cursor.getString(cursor.getColumnIndex("qq_t"));
            teacherBean.wechat = cursor.getString(cursor.getColumnIndex("wechat_t"));
            teacherBean.motto = cursor.getString(cursor.getColumnIndex("motto_t"));
            teacherBean.phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber_t"));
            teacherBean.password = cursor.getString(cursor.getColumnIndex("password_t"));
            teacherBean.isHead = cursor.getString(cursor.getColumnIndex("isHead_t"));

        }
        cursor.close();
        return teacherBean;
    }

    /**
     * 通过账号获取学生资料信息
     **/
    public StudentBean getStudentInfo(String studentName) {
        String sql = "SELECT * FROM " + DBOpenHelper.STUDENT_INFO + " WHERE userName_s=?";
        Cursor cursor = db.rawQuery(sql, new String[]{studentName});
        StudentBean studentBean = null;
        while (cursor.moveToNext()) {
            studentBean = new StudentBean();
            //将对应用户名的所有数据从表中动态赋值给bean
            studentBean.userName = cursor.getString(cursor.getColumnIndex("userName_s"));
            studentBean.realName = cursor.getString(cursor.getColumnIndex("realName_s"));
            studentBean.nickName = cursor.getString(cursor.getColumnIndex("nickName_s"));
            studentBean.sex = cursor.getString(cursor.getColumnIndex("sex_s"));
            studentBean.qq = cursor.getString(cursor.getColumnIndex("qq_s"));
            studentBean.wechat = cursor.getString(cursor.getColumnIndex("wechat_s"));
            studentBean.motto = cursor.getString(cursor.getColumnIndex("motto_s"));
            studentBean.ID = cursor.getString(cursor.getColumnIndex("studentID"));
            studentBean.password = cursor.getString(cursor.getColumnIndex("password_s"));
            studentBean.phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber_s"));
        }
        cursor.close();
        return studentBean;
    }
    /**
     * 通过学号获取学生资料信息
     **/
    public StudentBean getStudentInfoByID(String id) {
        String sql = "SELECT * FROM " + DBOpenHelper.STUDENT_INFO + " WHERE studentID=?";
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        StudentBean studentBean = null;
        while (cursor.moveToNext()) {
            studentBean = new StudentBean();
            //将对应用户名的所有数据从表中动态赋值给bean
            studentBean.userName = cursor.getString(cursor.getColumnIndex("userName_s"));
            studentBean.realName = cursor.getString(cursor.getColumnIndex("realName_s"));
            studentBean.nickName = cursor.getString(cursor.getColumnIndex("nickName_s"));
            studentBean.sex = cursor.getString(cursor.getColumnIndex("sex_s"));
            studentBean.qq = cursor.getString(cursor.getColumnIndex("qq_s"));
            studentBean.wechat = cursor.getString(cursor.getColumnIndex("wechat_s"));
            studentBean.motto = cursor.getString(cursor.getColumnIndex("motto_s"));
            studentBean.ID = cursor.getString(cursor.getColumnIndex("studentID"));
            studentBean.password = cursor.getString(cursor.getColumnIndex("password_s"));
            studentBean.phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber_s"));
        }
        cursor.close();
        return studentBean;
    }

    /**
     * 通过手机号获取学生资料信息
     **/
    public StudentBean getStudentInfoByPhoneNum(String phone) {
        String sql = "SELECT * FROM " + DBOpenHelper.STUDENT_INFO + " WHERE phoneNumber_s=?";
        Cursor cursor = db.rawQuery(sql, new String[]{phone});
        StudentBean studentBean = null;
        while (cursor.moveToNext()) {
            studentBean = new StudentBean();
            //将对应用户名的所有数据从表中动态赋值给bean
            studentBean.userName = cursor.getString(cursor.getColumnIndex("userName_s"));
            studentBean.realName = cursor.getString(cursor.getColumnIndex("realName_s"));
            studentBean.nickName = cursor.getString(cursor.getColumnIndex("nickName_s"));
            studentBean.sex = cursor.getString(cursor.getColumnIndex("sex_s"));
            studentBean.qq = cursor.getString(cursor.getColumnIndex("qq_s"));
            studentBean.wechat = cursor.getString(cursor.getColumnIndex("wechat_s"));
            studentBean.motto = cursor.getString(cursor.getColumnIndex("motto_s"));
            studentBean.ID = cursor.getString(cursor.getColumnIndex("studentID"));
            studentBean.password = cursor.getString(cursor.getColumnIndex("password_s"));
            studentBean.phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber_s"));

        }
        cursor.close();
        return studentBean;
    }

//  ---------------------------------------------------------------------------------------------
    /**
     * 通过ID获取管理员资料信息
     **/
    public UserBean getUserInfoByID(String id) {
        String sql = "SELECT * FROM " + DBOpenHelper.USER_INFO + " WHERE userID=?";
        Cursor cursor = db.rawQuery(sql, new String[]{id});
        UserBean userBean = null;
        while (cursor.moveToNext()) {
            userBean = new UserBean();
            //将对应用户名的所有数据从表中动态赋值给bean
            userBean.ID = cursor.getString(cursor.getColumnIndex("userID"));
            userBean.realName = cursor.getString(cursor.getColumnIndex("realName_u"));
            userBean.phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber_u"));
            userBean.identity = cursor.getString(cursor.getColumnIndex("identity"));
            userBean.isHead = cursor.getString(cursor.getColumnIndex("isHead_u"));
            userBean.classID = cursor.getString(cursor.getColumnIndex("classID_u"));
        }
        cursor.close();
        return userBean;
    }
    /**
     * 通过手机号获取管理员操作的资料信息
     **/
    public UserBean getUserInfoByPhoneNum(String phone) {
        String sql = "SELECT * FROM " + DBOpenHelper.USER_INFO + " WHERE phoneNumber_u=?";
        Cursor cursor = db.rawQuery(sql, new String[]{phone});
        UserBean userBean = null;
        while (cursor.moveToNext()) {
            userBean = new UserBean();
            //将对应用户名的所有数据从表中动态赋值给bean
            userBean.ID = cursor.getString(cursor.getColumnIndex("userID"));
            userBean.realName = cursor.getString(cursor.getColumnIndex("realName_u"));
            userBean.phoneNumber = cursor.getString(cursor.getColumnIndex("phoneNumber_u"));
            userBean.identity = cursor.getString(cursor.getColumnIndex("identity"));
            userBean.isHead = cursor.getString(cursor.getColumnIndex("isHead_u"));
            userBean.classID = cursor.getString(cursor.getColumnIndex("classID_u"));
        }
        cursor.close();
        return userBean;
    }

//  ---------------------------------------------------------------------------------------------

    /**
     * 根据用户名修改教师资料信息,这里的key指代表字段，value表示数值
     **/
    public void updateTeacherInfo(String key, String value, String userName) {
        ContentValues cv = new ContentValues();
        cv.put(key, value);
        db.update(DBOpenHelper.TEACHER_INFO, cv, "userName_t=?", new String[]{userName});
    }
    /**
     * 根据手机号修改教师资料信息,这里的key指代表字段，value表示数值
     **/
    public void updateTeacherInfoByPhone(String key, String value, String phone) {
        ContentValues cv = new ContentValues();
        cv.put(key, value);
        db.update(DBOpenHelper.TEACHER_INFO, cv, "phoneNumber_t=?", new String[]{phone});
    }

    /**
     * 根据ID修改学生资料信息,这里的key指代表字段，value表示数值
     **/
    public void updateStudentInfoByID(String key, String value, String id) {
        ContentValues cv = new ContentValues();
        cv.put(key, value);
        db.update(DBOpenHelper.STUDENT_INFO, cv, "studentID=?", new String[]{id});
    }
    /**
     * 根据手机号修改学生资料信息,这里的key指代表字段，value表示数值
     **/
    public void updateStudentInfoByPhone(String key, String value, String phone) {
        ContentValues cv = new ContentValues();
        cv.put(key, value);
        db.update(DBOpenHelper.STUDENT_INFO, cv, "phoneNumber_s=?", new String[]{phone});
    }
// --------------------------------！！！很重要！！！------------------------------------------------
    /**
     * 注册时的整体修改教师资料信息
     **/
    public void updateTeacherInfoAll(String id, TeacherBean teacherBean) {
        ContentValues cv = new ContentValues();
        cv.put("userName_t", teacherBean.userName);
        cv.put("nickName_t", teacherBean.nickName);
        cv.put("sex_t", teacherBean.sex);
        cv.put("qq_t", teacherBean.qq);
        cv.put("wechat_t",teacherBean.wechat);
        cv.put("motto_t",teacherBean.motto);
        cv.put("password_t",teacherBean.password);
        db.update(DBOpenHelper.TEACHER_INFO, cv, "teacherID=?", new String[]{id});
    }

    /**
     * 注册时的整体修改学生资料信息
     **/
    public void updateStudentInfoAll(String id, StudentBean studentBean) {
        ContentValues cv = new ContentValues();
        cv.put("userName_s", studentBean.userName);
        cv.put("nickName_s", studentBean.nickName);
        cv.put("sex_s", studentBean.sex);
        cv.put("qq_s", studentBean.qq);
        cv.put("wechat_s",studentBean.wechat);
        cv.put("motto_s",studentBean.motto);
        cv.put("password_s",studentBean.password);
        db.update(DBOpenHelper.STUDENT_INFO, cv, "studentID=?", new String[]{id});
    }

    /**
     * 注册时的修改学生与班级的绑定信息
     **/
    public void updateClassInfoAll(String id, ClassBean classBean) {
        ContentValues cv = new ContentValues();
        cv.put("classID", classBean.classID);
        cv.put("className", classBean.className);
        cv.put("year", classBean.year);
        cv.put("code", classBean.code);
        cv.put("teacherID_c", classBean.teacherID);
        cv.put("teacherName_c", classBean.teacherName);
        db.update(DBOpenHelper.CLASS, cv, "studentID_c=?", new String[]{id});
    }

}
