package com.henry.myschoolsystem.ui.me;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import com.henry.myschoolsystem.R;

public class FeedbackActivity extends AppCompatActivity {

    private RatingBar ratingBar;
    private EditText editText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedback);

        ratingBar = findViewById(R.id.ratingBar);
        editText = findViewById(R.id.et_feedBack);
        Button button = findViewById(R.id.btn_feedBack);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editText.getText().toString().trim().equals("")) {
                    Toast.makeText(FeedbackActivity.this, "请先填写反馈和建议的内容噢~", Toast.LENGTH_LONG).show();
                } else {
                    float rating = ratingBar.getRating();
                    Toast.makeText(FeedbackActivity.this, "提交成功！已收到您的" + rating + "星评价", Toast.LENGTH_LONG).show();
                    editText.setText("");
                }
            }
        });
    }
}
