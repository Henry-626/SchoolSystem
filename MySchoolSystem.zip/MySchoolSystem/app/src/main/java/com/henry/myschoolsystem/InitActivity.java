package com.henry.myschoolsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.henry.myschoolsystem.ui.admin.AdminActivity;
import com.henry.myschoolsystem.ui.admin.StudentActivity;
import com.henry.myschoolsystem.ui.login.SLoginActivity;
import com.henry.myschoolsystem.ui.login.TLoginActivity;

public class InitActivity extends AppCompatActivity {

    private EditText et_name, et_pwd;

    //初始登录界面，由此选择老师端、学生端或是管理员
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_init);

        RelativeLayout chooseTeacher = (RelativeLayout) findViewById(R.id.ChooseTeacher);
        chooseTeacher.setOnClickListener(new JumpTeacher());    //教师登录页面跳转

        RelativeLayout chooseStudent = (RelativeLayout) findViewById(R.id.ChooseStudent);
        chooseStudent.setOnClickListener(new JumpStudent());    //学生登录页面跳转

        RelativeLayout chooseAdmin = (RelativeLayout) findViewById(R.id.ChooseAdmin);
        chooseAdmin.setOnClickListener(new JumpAdmin());    //管理员页面跳转
    }

    private class JumpTeacher implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent();
            intent.setClass(InitActivity.this, TLoginActivity.class);
            startActivity(intent);
        }
    }

    private class JumpStudent implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent();
            intent.setClass(InitActivity.this, SLoginActivity.class);
            startActivity(intent);
        }
    }

    private class JumpAdmin implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            customClick(view); //调用自定义的Dialog
        }
    }

    /**
     * 自定义登录对话框
     */
    private void customClick(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(InitActivity.this);
        final AlertDialog dialog = builder.create();
        final View dialogView = View.inflate(InitActivity.this, R.layout.dialog_admin_login, null);
        //设置对话框布局
        dialog.setView(dialogView);
        dialog.show();
        dialog.getWindow().setBackgroundDrawable(null);
        final Button btnLogin = (Button) dialogView.findViewById(R.id.btn_login);
        final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_cancel);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                et_name = (EditText) dialogView.findViewById(R.id.et_name);
                et_pwd = (EditText) dialogView.findViewById(R.id.et_pwd);
                String name = et_name.getText().toString().trim();
                String pwd = et_pwd.getText().toString().trim();
                if (name.equals("") || pwd.equals("")) {
                    Toast.makeText(InitActivity.this, "账号和密码都不能为空呀，请重新填写", Toast.LENGTH_SHORT).show();
                } else {
                    if (name.equals("Henry")) {
                        if (pwd.equals("666666")) {
                            Intent intent = new Intent();
                            intent.setClass(InitActivity.this, AdminActivity.class);
                            startActivity(intent);
                            dialog.dismiss();
                        } else {
                            Toast.makeText(InitActivity.this, "密码不正确，请重新填写", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        Toast.makeText(InitActivity.this, "账号不正确，请重新填写", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }
}
