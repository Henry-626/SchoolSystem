package com.henry.myschoolsystem.bean;

public class UserBean {
    public String ID;  //学生学号或教师工号
    public String realName;  //真实姓名
    public String phoneNumber;  //手机号
    public String identity;  //标记身份
    public String isHead;  //标记是否为班主任
    public String classID;  //绑定班级ID
}
