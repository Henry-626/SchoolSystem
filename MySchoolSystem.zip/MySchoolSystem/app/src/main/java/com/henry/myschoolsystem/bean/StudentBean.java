package com.henry.myschoolsystem.bean;

public class StudentBean {
    public String userName;  //账号
    public String realName;  //真实姓名
    public String nickName;  //昵称
    public String sex;    //性别
    public String qq;  //QQ号
    public String wechat;  //微信号
    public String motto;  //个性签名
    public String ID;  //学生学号
    public String password;  //密码
    public String phoneNumber;  //手机号
}
