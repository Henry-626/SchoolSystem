package com.henry.myschoolsystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.os.Bundle;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.henry.myschoolsystem.bean.LogBean;
import com.henry.myschoolsystem.utils.CurrentUser;
import com.henry.myschoolsystem.utils.DBUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class TMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tmain);
        BottomNavigationView navView2 = findViewById(R.id.nav_view2);

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");// HH:mm:ss
        //获取当前时间
        Date date = new Date(System.currentTimeMillis());
        LogBean bean = new LogBean();
        bean.userID = CurrentUser.getuserID();
        bean.userName = CurrentUser.getRealName();
        bean.time = "登录时间：" + simpleDateFormat.format(date);
        saveLog(bean);
        Toast.makeText(TMainActivity.this, bean.time, Toast.LENGTH_LONG).show();

        AppBarConfiguration appBarConfiguration2 = new AppBarConfiguration.Builder(
                R.id.navigation_tluntan, R.id.navigation_tstudy, R.id.navigation_tplan, R.id.navigation_tme)
                .build();
        NavController navController2 = Navigation.findNavController(this, R.id.nav_host_fragment2);
        NavigationUI.setupActionBarWithNavController(this, navController2, appBarConfiguration2);
        NavigationUI.setupWithNavController(navView2, navController2);
    }
    private void saveLog(LogBean logBean) {
        DBUtils.getInstance(this).savaLogInfo(logBean);
    }
}
