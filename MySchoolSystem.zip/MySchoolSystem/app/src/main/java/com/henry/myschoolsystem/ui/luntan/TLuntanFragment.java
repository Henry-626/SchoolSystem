package com.henry.myschoolsystem.ui.luntan;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.ViewSwitcher;

import com.henry.myschoolsystem.R;


public class TLuntanFragment extends Fragment {

    private int[] arrayPicture = new int[] {R.mipmap.img1,R.mipmap.img2,
            R.mipmap.img3,R.mipmap.img4,R.mipmap.img5,R.mipmap.img6,
            R.mipmap.img7,R.mipmap.img8,R.mipmap.img9};
    private ImageSwitcher imageSwitcher;
    private int index;
    private float touchDownX;
    private float touchUpX;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_tluntan, container, false);
        imageSwitcher = (ImageSwitcher) root.findViewById(R.id.imageSwitch_t);
        imageSwitcher.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                ImageView imageView = new ImageView(getActivity());
                imageView.setImageResource(arrayPicture[index]);
                return imageView;
            }
        });
        imageSwitcher.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction()==MotionEvent.ACTION_DOWN) {
                    touchDownX = event.getX();
                    return true;
                } else if (event.getAction()==MotionEvent.ACTION_UP) {
                    touchUpX = event.getX();
                    if(touchUpX-touchDownX>100) { //从左向右滑
                        index = index ==0?arrayPicture.length-1:index-1;
                        imageSwitcher.setInAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.slide_in_left));
                        imageSwitcher.setOutAnimation(AnimationUtils.loadAnimation(getActivity(),R.anim.slide_out_right));
                        imageSwitcher.setImageResource(arrayPicture[index]);
                    } else if (touchDownX-touchUpX>100) {  //从右向左滑
                        index = index ==arrayPicture.length-1?0:index+1;
                        imageSwitcher.setInAnimation(AnimationUtils.loadAnimation(getActivity(),R.anim.slide_in_right));
                        imageSwitcher.setOutAnimation(AnimationUtils.loadAnimation(getActivity(),R.anim.slide_out_left));
                        imageSwitcher.setImageResource(arrayPicture[index]);
                    }
                    return true;
                }
                return false;
            }
        });
        return root;
    }
}
