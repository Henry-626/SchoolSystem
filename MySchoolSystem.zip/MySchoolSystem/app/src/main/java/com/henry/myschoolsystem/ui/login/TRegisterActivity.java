package com.henry.myschoolsystem.ui.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.Selection;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.bean.StudentBean;
import com.henry.myschoolsystem.bean.TeacherBean;
import com.henry.myschoolsystem.utils.DBUtils;
import com.henry.myschoolsystem.utils.LimitName;
import com.henry.myschoolsystem.utils.MD5Utils;
import com.henry.myschoolsystem.utils.PhoneNumberUtils;

import org.json.JSONException;
import org.json.JSONObject;

import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;

public class TRegisterActivity extends AppCompatActivity {

    private Button buttonCode, buttonRegister;
    private EditText editTextPhoneNum, editTextCode, editTextUserName, editTextPassword, editConfirmPassword;
    private String phoneNum, code, userName, password, confirm;
    private EventHandler eh;
    private int counter1 = 0, counter2 = 0;  //限制弹窗的次数，防止用户一直不符合规则，弹窗弹个不停

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tregister);
        buttonCode = findViewById(R.id.buttonCode);
        buttonRegister = findViewById(R.id.buttonRegister);
        editTextCode = findViewById(R.id.editTextCode);
        editTextPhoneNum = findViewById(R.id.editTextPhoneNum);
        editTextUserName = findViewById(R.id.add_username);
        editTextPassword = findViewById(R.id.add_password);
        editConfirmPassword = findViewById(R.id.confirm_password);

        //修改注册按钮的字体
        Typeface customFont = Typeface.createFromAsset(this.getAssets(), "fonts/Coca-Cola.TTF");
        buttonRegister.setTypeface(customFont);

        nameCntentListener();
        passwordCntentListener();

        eh = new EventHandler() {
            @Override
            public void afterEvent(int event, int result, Object data) {
                if (result == SMSSDK.RESULT_COMPLETE) {
                    //回调完成
                    if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) {
                        //提交验证码成功
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                userName = editTextUserName.getText().toString().trim();
                                password = editTextPassword.getText().toString().trim();
                                phoneNum = editTextPhoneNum.getText().toString().trim();
                                confirm = editConfirmPassword.getText().toString().trim();

                                //如果填写的用户名或密码为空时
                                if (userName.equals("") || password.equals("")) {
                                    Toast.makeText(TRegisterActivity.this, "账号或密码为空，请重新填写", Toast.LENGTH_SHORT).show();
                                } else {
                                    if (!LimitName.limitName(userName)) {
                                        Toast.makeText(TRegisterActivity.this, "账号仅允许英文字母、数字和-的组合", Toast.LENGTH_SHORT).show();
                                    } else {
                                        nameCntentListener();
                                        passwordCntentListener();
                                        if (!password.equals(confirm)) {  //两次输入的密码不一致
                                            Toast.makeText(TRegisterActivity.this, "两次输入的密码不一致，请重新输入", Toast.LENGTH_SHORT).show();
                                            editConfirmPassword.setText(""); //将输入框内容清除
                                            editTextPassword.setText("");
                                        } else {
                                            TeacherBean bean = null;
                                            TeacherBean teacherBean = null;
                                            bean = getTeacherData(userName);
                                            if (bean != null) {   //说明就不是暂无了
                                                Toast.makeText(TRegisterActivity.this, "该用户已存在！", Toast.LENGTH_SHORT).show();
                                                editTextUserName.setText(""); //将输入框内容清除
                                                editTextPassword.setText("");
                                                editConfirmPassword.setText("");
                                                editTextCode.setText("");
                                            } else {
                                                teacherBean = getTeacherDataByPhoneNum(phoneNum);   //因为还未绑定用户名，所以只能用手机号获取到ID绑定用户
                                                teacherBean.userName = userName;
                                                teacherBean.nickName = "快给自己起个昵称叭";
                                                teacherBean.sex = "待定";
                                                teacherBean.qq = "待定";
                                                teacherBean.wechat = "待定";
                                                teacherBean.motto = "有点懒吖，啥都没写~";
                                                teacherBean.password = MD5Utils.md5(password);
                                                //保存到数据库
                                                insertTeacher(teacherBean.ID, teacherBean);
                                                Toast.makeText(TRegisterActivity.this, "注册成功!", Toast.LENGTH_SHORT).show();
                                                Intent intent = new Intent(TRegisterActivity.this, TLoginActivity.class);
                                                startActivity(intent);
                                                finish();  //销毁本Activity
                                            }
                                        }
                                    }
                                }
                            }
                        });
                    } else if (event == SMSSDK.EVENT_GET_VOICE_VERIFICATION_CODE) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(TRegisterActivity.this, "语音验证发送", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE) {
                        //获取验证码成功
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(TRegisterActivity.this, "验证码已发送", Toast.LENGTH_SHORT).show();
                            }
                        });
                    } else if (event == SMSSDK.EVENT_GET_SUPPORTED_COUNTRIES) {
                        Log.i("test", "test");
                    }
                } else {
                    ((Throwable) data).printStackTrace();
                    Throwable throwable = (Throwable) data;
                    throwable.printStackTrace();
                    Log.i("1234", throwable.toString());
                    try {
                        JSONObject obj = new JSONObject(throwable.getMessage());
                        final String des = obj.optString("detail");
                        if (!TextUtils.isEmpty(des)) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(TRegisterActivity.this, des, Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }

        ;

        //注册一个事件回调监听，用于处理SMSSDK接口请求的结果
        SMSSDK.registerEventHandler(eh);
        buttonCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phoneNum = editTextPhoneNum.getText().toString();
                if (!phoneNum.isEmpty()) {
                    if (PhoneNumberUtils.checkTel(phoneNum)) { //利用正则表达式检验手机号
                        TeacherBean bean = null;
                        StudentBean bean2 = null;
                        //检查数据库中该手机号是否已经被绑定
                        bean = getTeacherDataByPhoneNum(phoneNum);
                        bean2 = getStudentDataByPhoneNum(phoneNum);
                        if (bean == null && bean2 == null) {
                            Toast.makeText(TRegisterActivity.this, "该手机号不可用，需要先以管理员身份添加", Toast.LENGTH_SHORT).show();
                        } else {
                            if (bean != null) {
                                if (!bean.userName.equals("暂无")) {
                                    Toast.makeText(TRegisterActivity.this, "该手机号已绑定过用户！", Toast.LENGTH_SHORT).show();
                                } else {
                                    if (bean2 != null) {
                                        if (!bean2.userName.equals("暂无")) {
                                            Toast.makeText(TRegisterActivity.this, "该手机号已绑定过用户！", Toast.LENGTH_SHORT).show();
                                        } else {
                                            // 获取验证码
                                            SMSSDK.getVerificationCode("86", phoneNum);
                                        }
                                    } else {   //bean2 = null, 则肯定未绑定
                                        // 获取验证码
                                        SMSSDK.getVerificationCode("86", phoneNum);
                                    }
                                }
                            } else {
                                if (!bean2.userName.equals("暂无")) {
                                    Toast.makeText(TRegisterActivity.this, "该手机号已绑定过用户！", Toast.LENGTH_SHORT).show();
                                } else {
                                    // 获取验证码
                                    SMSSDK.getVerificationCode("86", phoneNum);
                                }
                            }
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "请输入有效的手机号", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "请输入手机号", Toast.LENGTH_SHORT).show();
                    return;
                }
                phoneNum = editTextPhoneNum.getText().toString();
            }
        });
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                code = editTextCode.getText().toString();
                if (!code.isEmpty()) {
                    //提交验证码
                    SMSSDK.submitVerificationCode("86", phoneNum, code);
                } else {
                    Toast.makeText(getApplicationContext(), "请输入验证码", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });
    }

    /**
     * 监听账号输入框的文字
     **/
    private void nameCntentListener() {
        editTextUserName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Editable editable = editTextUserName.getText();
                int len = editable.length();//输入文本的长度
                if (len > 10) {
                    int selEndIndex = Selection.getSelectionEnd(editable);
                    String str = editable.toString();
                    //截取新字符串
                    String newStr = str.substring(0, 10);
                    editTextUserName.setText(newStr);
                    editable = editTextUserName.getText();
                    //新字符串长度
                    int newLen = editable.length();
                    //旧光标位置超过新字符串长度
                    if (selEndIndex > newLen) {
                        selEndIndex = editable.length();
                    }
                    //设置新光标的位置
                    Selection.setSelection(editable, selEndIndex);
                    if (counter1 < 3) { //事不过三哈哈哈
                        Toast.makeText(TRegisterActivity.this, "账号最多10位吖！", Toast.LENGTH_SHORT).show();
                        counter1++;
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    /**
     * 监听密码输入框的文字
     **/
    private void passwordCntentListener() {
        editTextPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Editable editable = editTextPassword.getText();
                int len = editable.length();//输入文本的长度
                if (len > 16) {
                    int selEndIndex = Selection.getSelectionEnd(editable);
                    String str = editable.toString();
                    String newStr = str.substring(0, 16);
                    editTextPassword.setText(newStr);
                    editable = editTextPassword.getText();
                    int newLen = editable.length();
                    if (selEndIndex > newLen) {
                        selEndIndex = editable.length();
                    }
                    Selection.setSelection(editable, selEndIndex);
                    if (counter2 < 3) { //事不过三哈哈哈
                        Toast.makeText(TRegisterActivity.this, "密码最多16位吖！", Toast.LENGTH_SHORT).show();
                        counter2++;
                    }

                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private void insertTeacher(String id, TeacherBean bean) {
        DBUtils.getInstance(this).updateTeacherInfoAll(id, bean);
    }

    private TeacherBean getTeacherData(String key) {
        TeacherBean bean = DBUtils.getInstance(this).getTeacherInfo(key);
        return bean;
    }

    private TeacherBean getTeacherDataByPhoneNum(String phone) {
        TeacherBean bean = DBUtils.getInstance(this).getTeacherInfoByPhoneNum(phone);
        return bean;
    }

    //还需要检查填入的手机号是否与学生用户绑定
    private StudentBean getStudentDataByPhoneNum(String phone) {
        StudentBean bean = DBUtils.getInstance(this).getStudentInfoByPhoneNum(phone);
        return bean;
    }

    // 使用完EventHandler需注销，否则可能出现内存泄漏
    @Override
    protected void onDestroy() {
        super.onDestroy();
        SMSSDK.unregisterEventHandler(eh);
    }
}
