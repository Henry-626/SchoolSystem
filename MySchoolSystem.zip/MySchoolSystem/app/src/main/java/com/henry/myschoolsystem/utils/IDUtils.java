package com.henry.myschoolsystem.utils;

import java.io.OptionalDataException;

public class IDUtils {
    public static String[] studentID= {"202001","202002","202003","202004","202005","202006","202007","202008","202009","202010"};
    public static String[] studentRealName= {"Harry","Jack","Mary","Nick","Mike","Lucy","Jason","Henry","Paul","Tim"};
}
