package com.henry.myschoolsystem.utils;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.henry.myschoolsystem.R;

public class Maintain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maintain);
    }
}
