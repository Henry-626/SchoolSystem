package com.henry.myschoolsystem.ui.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.henry.myschoolsystem.InitActivity;
import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.ui.login.SLoginActivity;
import com.henry.myschoolsystem.ui.login.TLoginActivity;

public class AdminActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        RelativeLayout chooseTeacher = (RelativeLayout) findViewById(R.id.admin_teacher);
        chooseTeacher.setOnClickListener(new JumpTeacher());    //管理教师用户页面跳转

        RelativeLayout chooseStudent = (RelativeLayout) findViewById(R.id.admin_student);
        chooseStudent.setOnClickListener(new JumpStudent());    //管理学生用户页面跳转

        RelativeLayout chooseClass = (RelativeLayout) findViewById(R.id.admin_class);
        chooseClass.setOnClickListener(new JumpClass());    //管理班级页面跳转
    }

    private class JumpTeacher implements View.OnClickListener{
        @Override
        public void onClick(View view){
            selectClick(view);  //调用自定义的dialog
        }
    }

    private class JumpStudent implements View.OnClickListener{
        @Override
        public void onClick(View view){
            Intent intent = new Intent();
            intent.setClass(AdminActivity.this, StudentActivity.class);
            startActivity(intent);
        }
    }

    private class JumpClass implements View.OnClickListener{
        @Override
        public void onClick(View view){
            Intent intent = new Intent();
            intent.setClass(AdminActivity.this, ClassActivity.class);
            startActivity(intent);
        }
    }

    /**
     * 自定义选择对话框
     */
    private void selectClick(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(AdminActivity.this);
        final AlertDialog dialog = builder.create();
        final View dialogView = View.inflate(AdminActivity.this, R.layout.dialog_admin_teacher, null);
        //设置对话框布局
        dialog.setView(dialogView);
        dialog.show();
        dialog.getWindow().setBackgroundDrawable(null);
        final Button btnHead = (Button) dialogView.findViewById(R.id.btn_selectHead);
        final Button btnTeacher = (Button) dialogView.findViewById(R.id.btn_selectTeacher);
        btnHead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                            Intent intent = new Intent();
                            intent.setClass(AdminActivity.this, TeacherActivity.class);
                            startActivity(intent);
                            dialog.dismiss();
                        }
        });
        btnTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(AdminActivity.this, Teacher2Activity.class);
                startActivity(intent);
                dialog.dismiss();
            }
        });
    }
}
