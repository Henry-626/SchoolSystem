package com.henry.myschoolsystem.bean;

public class CourseBean {
    public String courseId;
    public String courseName;
    public String teacherName;
    public String studentName;
    public String credit;  //该课程学分
    public String grade;  //学生所得分数
}
