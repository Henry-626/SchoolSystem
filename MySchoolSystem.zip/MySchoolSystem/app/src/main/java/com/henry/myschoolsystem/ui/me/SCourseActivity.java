package com.henry.myschoolsystem.ui.me;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.henry.myschoolsystem.R;

public class SCourseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maintain);
    }
}
