package com.henry.myschoolsystem.ui.study;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.ui.me.AboutActivity;
import com.henry.myschoolsystem.ui.me.FeedbackActivity;
import com.henry.myschoolsystem.ui.me.InstructionsActivity;
import com.henry.myschoolsystem.ui.me.LogActivity;
import com.henry.myschoolsystem.ui.me.TInfoActivity;
import com.henry.myschoolsystem.ui.me.TMeFragment;
import com.henry.myschoolsystem.ui.me.XzActivity;
import com.henry.myschoolsystem.utils.Maintain;

public class TStudyFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_tstudy, container, false);
        RelativeLayout chooseCourse = root.findViewById(R.id.ChooseMyCourses);
        chooseCourse.setOnClickListener(new Jump());
        RelativeLayout chooseClass = root.findViewById(R.id.ChooseMyClass);
        chooseClass.setOnClickListener(new Jump());
        TextView tv_chuti = root.findViewById(R.id.ChooseChuti);
        tv_chuti.setOnClickListener(new Jump());
        return root;
    }

    private class Jump implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent();
            intent.setClass(getActivity(), Maintain.class);
            startActivity(intent);
//            switch (view.getId()) {       //根据RelativeLayout组件的id进行判断
//                case R.id.ChooseMyCourses:
//                    intent.setClass(getActivity(), Maintain.class);
//                    startActivity(intent);
//                    break;
//                case R.id.ChooseMyClass:
//                    intent.setClass(getActivity(), Maintain.class);
//                    startActivity(intent);
//                    break;
//                case R.id.ChooseChuti:
//                    intent.setClass(getActivity(), Maintain.class);
//                    startActivity(intent);
//                    break;
//        }
        }
    }
}
