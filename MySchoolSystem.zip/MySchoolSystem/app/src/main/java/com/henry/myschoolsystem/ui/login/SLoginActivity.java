package com.henry.myschoolsystem.ui.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.Selection;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.SMainActivity;
import com.henry.myschoolsystem.bean.StudentBean;
import com.henry.myschoolsystem.utils.CurrentUser;
import com.henry.myschoolsystem.utils.DBUtils;
import com.henry.myschoolsystem.utils.MD5Utils;

public class SLoginActivity extends AppCompatActivity {
    private EditText usernameEditText2, passwordEditText2;
    private Button btn_Save2, btn_Login2;
    private TextView tv_student, btn_forget2;
    private int counter1 = 0, counter2 = 0;  //限制弹窗的次数，防止用户一直不符合规则，弹窗弹个不停

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slogin);

        usernameEditText2 = findViewById(R.id.login_username2);           //获取添加用户名的编辑框
        passwordEditText2 = findViewById(R.id.login_password2);  //获取添加密码的编辑框
        btn_Save2 = findViewById(R.id.register2);      //获取注册按钮
        btn_Login2 = findViewById(R.id.login2);     //获取登录按钮
        btn_forget2 = findViewById(R.id.forget2);   //获取忘记密码
        tv_student = findViewById(R.id.tv_student);   //获取学生登录的TextView

        //修改以下三个组件的字体
        Typeface customFont = Typeface.createFromAsset(this.getAssets(), "fonts/Coca-Cola.TTF");
        tv_student.setTypeface(customFont);
        btn_Save2.setTypeface(customFont);
        btn_Login2.setTypeface(customFont);

        nameCntentListener();
        passwordCntentListener();

        //登录
        btn_Login2.setOnClickListener(new View.OnClickListener() {  //单击登录按钮查看是否有该用户以及密码是否正确
            @Override
            public void onClick(View v) {
                String student = usernameEditText2.getText().toString().trim();//获取输入的登录名
                StudentBean studentBean = null;
                //实例化DBUtils，同时调用其方法获取个人信息资料
                studentBean = getStudentData(student);
                if (studentBean == null) {
                    Toast.makeText(SLoginActivity.this, "该账号不存在，请重新输入或注册！", Toast.LENGTH_SHORT).show();
                } else {
                    String passwordIn = passwordEditText2.getText().toString().trim(); //获取输入的密码
                    nameCntentListener();
                    passwordCntentListener();
                    if (studentBean.password.equals(MD5Utils.md5(passwordIn))) {   //只是比较内容，不能用==
                        Toast.makeText(SLoginActivity.this, "登录成功！" + student + "，欢迎您~", Toast.LENGTH_SHORT).show();

                        CurrentUser.setUserID(studentBean.ID);//将登录成功的当前登录用户的ID、账号、姓名和昵称存为全局变量
                        CurrentUser.setUserName(student);
                        CurrentUser.setRealName(studentBean.realName);
                        CurrentUser.setNickName(studentBean.nickName);
                        Intent intent = new Intent(SLoginActivity.this, SMainActivity.class);  //登录成功跳转学生主界面
                        startActivity(intent);
                        finish();
                    } else {
                        if (passwordIn.equals("")) {
                            Toast.makeText(SLoginActivity.this, "密码不能为空哦！", Toast.LENGTH_SHORT).show();
                        } else {
                            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(SLoginActivity.this);
                            final android.app.AlertDialog dialog = builder.create();
                            final View dialogView = View.inflate(SLoginActivity.this, R.layout.dialog_forget, null);
                            //设置对话框布局
                            dialog.setView(dialogView);
                            dialog.show();
                            dialog.getWindow().setBackgroundDrawable(null);
                            final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_Login_cancel);
                            final Button btnForget = (Button) dialogView.findViewById(R.id.btn_Login_forget);
                            btnForget.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    dialog.dismiss();
                                    Intent intent = new Intent(SLoginActivity.this, SForgetActivity.class);  //跳转至忘记密码界面
                                    startActivity(intent);
                                    finish();
                                }
                            });
                            btnCancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Toast.makeText(SLoginActivity.this, "您选择了重新输入，输入要细心哈", Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                }
                            });
                        }
                    }
                }
            }
        });
        //注册
        btn_Save2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SLoginActivity.this, SRegisterActivity.class);  //跳转至注册页面
                startActivity(intent);
                finish();
            }
        });
        //忘记密码
        btn_forget2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SLoginActivity.this, SForgetActivity.class);  //跳转至学生端忘记密码页面
                startActivity(intent);
                finish();
            }
        });
    }

    /**
     * 监听账号输入框的文字
     **/
    private void nameCntentListener() {
        usernameEditText2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Editable editable = usernameEditText2.getText();
                int len = editable.length();//输入文本的长度
                if (len > 10) {
                    int selEndIndex = Selection.getSelectionEnd(editable);
                    String str = editable.toString();
                    //截取新字符串
                    String newStr = str.substring(0, 10);
                    usernameEditText2.setText(newStr);
                    editable = usernameEditText2.getText();
                    //新字符串长度
                    int newLen = editable.length();
                    //旧光标位置超过新字符串长度
                    if (selEndIndex > newLen) {
                        selEndIndex = editable.length();
                    }
                    //设置新光标的位置
                    Selection.setSelection(editable, selEndIndex);
                    if (counter1 < 3) { //事不过三哈哈哈
                        Toast.makeText(SLoginActivity.this, "账号最多10位吖！", Toast.LENGTH_SHORT).show();
                        counter1++;
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    /**
     * 监听密码输入框的文字
     **/
    private void passwordCntentListener() {
        passwordEditText2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Editable editable = passwordEditText2.getText();
                int len = editable.length();//输入文本的长度
                if (len > 16) {
                    int selEndIndex = Selection.getSelectionEnd(editable);
                    String str = editable.toString();
                    String newStr = str.substring(0, 16);
                    passwordEditText2.setText(newStr);
                    editable = passwordEditText2.getText();
                    int newLen = editable.length();
                    if (selEndIndex > newLen) {
                        selEndIndex = editable.length();
                    }
                    Selection.setSelection(editable, selEndIndex);
                    if (counter2 < 3) { //事不过三哈哈哈
                        Toast.makeText(SLoginActivity.this, "密码最多16位吖！", Toast.LENGTH_SHORT).show();
                        counter2++;
                    }
                }

            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private StudentBean getStudentData(String key) {
        StudentBean bean = DBUtils.getInstance(this).getStudentInfo(key);
        return bean;
    }
}
