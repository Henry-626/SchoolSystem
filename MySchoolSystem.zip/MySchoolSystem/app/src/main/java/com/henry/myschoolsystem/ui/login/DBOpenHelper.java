package com.henry.myschoolsystem.ui.login;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBOpenHelper extends SQLiteOpenHelper {
    public static final String TEACHER_INFO = "teacherInfo";
    public static final String STUDENT_INFO = "studentInfo";
    public static final String CLASS = "class";
    public static final String COURSE = "course";
    public static final String SPLAN = "studentPlan";
    public static final String SPLANFINISHED = "studentPlanFinished";
    public static final String TPLAN = "teacherPlan";
    public static final String TPLANFINISHED = "teacherPlanFinished";
    public static final String USER_INFO = "userInfo";
    public static final String LOG = "userLog";


//    public DBOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
//        super(context, name, null, version);     //重写构造方法并设置factory为null
//    }

    public DBOpenHelper(Context context){
        super(context, "mySchool0030.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        /**
         * 当该子类被实例化时会创建指定名的数据库，在onCreate中按以下的SQL语句创建相应的表
         **/
        db.execSQL("CREATE TABLE IF NOT EXISTS " + USER_INFO + "( "
                + "_id integer primary key autoincrement, "
                + "userID TEXT UNIQUE NOT NULL, "
                + "realName_u TEXT NOT NULL, "  //真实姓名（教师或学生）
                + "phoneNumber_u TEXT, "
                + "identity TEXT NOT NULL,"   //用来标记该用户是教师还是学生（0：教师，1：学生）
                + "isHead_u TEXT,"  //添加的是教师时用来标记是否为班主任（0：不是，1：是）
                + "classID_u TEXT"  //是班主任的话需填写班级ID
                + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TEACHER_INFO + "( "
                + "teacherID TEXT PRIMARY KEY, "
                + "userName_t TEXT NOT NULL, "
                + "realName_t TEXT NOT NULL, " //真实姓名
                + "nickName_t TEXT, "  //昵称
                + "isHead_t TEXT NOT NULL, "  //标记是否为班主任 （0：不是，1：是）
                + "sex_t TEXT, "
                + "qq_t TEXT, "
                + "wechat_t TEXT, "
                + "motto_t TEXT, "
                + "phoneNumber_t TEXT NOT NULL, "
                + "password_t TEXT NOT NULL"
                + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + STUDENT_INFO + "( "
                + "studentID TEXT PRIMARY KEY, "
                + "userName_s TEXT NOT NULL, "
                + "realName_s TEXT NOT NULL, "  //真实姓名
                + "nickName_s TEXT, "  //昵称
                + "sex_s TEXT, "
                + "qq_s TEXT, "
                + "wechat_s TEXT, "
                + "motto_s TEXT, "
                + "phoneNumber_s TEXT, "
                + "password_s TEXT NOT NULL"
                + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + CLASS + "( "
                + "_id integer primary key autoincrement, "
                + "classID TEXT NOT NULL, "
                + "className TEXT NOT NULL, "
                + "year TEXT NOT NULL, "  //年级
                + "studentID_c TEXT, "
                + "teacherID_c TEXT, "
                + "teacherName_c TEXT, "  //班主任姓名
                + "code TEXT NOT NULL "  //学生加入班级需要的验证码
                + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + COURSE + "( "
                + "courseID TEXT PRIMARY KEY, "
                + "courseName TEXT NOT NULL, "
                + "studentID TEXT REFERENCES studentInfo(studentID), "
                + "teacherName TEXT REFERENCES teacherInfo(realName_t), " //任课教师姓名
                + "grade TEXT, "  //学生所得分数
                + "credit TEXT NOT NULL "  //该课程的学分
                + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + SPLAN + "( "
                + "_id integer primary key autoincrement, "
                + "planContent_s TEXT, " //计划的具体内容
                + "studentID_p TEXT, "
                + "deadline_s TEXT" //计划的最终期限
                + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + SPLANFINISHED + "( "
                + "_id integer primary key autoincrement, "
                + "studentID_pf TEXT, "
                + "finishedTime_s TEXT, " //计划的完成时间
                + "finishedContent_s TEXT " //完成的计划内容
                + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TPLAN + "( "
                + "_id integer primary key autoincrement, "
                + "planContent_t TEXT, " //计划的具体内容
                + "TeacherID_p TEXT, "
                + "deadline_t TEXT " //计划的最终期限
                + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TPLANFINISHED + "( "
                + "_id integer primary key autoincrement, "
                + "teacherID_pf TEXT, "
                + "finishedTime_t TEXT, " //计划的完成时间
                + "finishedContent_t TEXT " //完成的计划内容
                + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + LOG + "( "
                + "_id integer primary key autoincrement, "
                + "userID_l TEXT NOT NULL, " //登录的用户ID
                + "userName_l TEXT NOT NULL, " //登录的用户姓名
                + "logContent TEXT NOT NULL " //日志的具体内容
                + ")");
    }


    @Override
    // 重写基类的onUpgrade()方法，以便数据库版本更新
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //提示版本更新并输出旧版本信息与新版本信息
        System.out.println("---版本更新-----" + oldVersion + "--->" + newVersion);
    }
}
