package com.henry.myschoolsystem.ui.admin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.cursoradapter.widget.SimpleCursorAdapter;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.henry.myschoolsystem.InitActivity;
import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.ui.login.DBOpenHelper;
import com.henry.myschoolsystem.ui.login.TLoginActivity;
import com.henry.myschoolsystem.utils.PhoneNumberUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentActivity extends AppCompatActivity implements View.OnClickListener {

    private List<Map<String, String>> list = new ArrayList<>();
    private ListView listView;
    private Button btn_insert, btn_search;
    private EditText et_ID, et_name, et_phone, et_search, et_dialog_name, et_dialog_phone;
    private SimpleCursorAdapter simpleCursorAdapter;
    private SQLiteDatabase mDbWriter;
    private SQLiteDatabase mDbReader;
    private DBOpenHelper openHelper;
    private int flag;  //用于区分查询结果的弹窗显示

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        initView();
        initEvent();

        //单击修改item
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, final View view, final int position, long l) {
                View mView = View.inflate(StudentActivity.this, R.layout.dialog_et_layout, null);       //将放置了两个EditText的布局dialog_et_layout渲染成view对象
                et_dialog_name = (EditText) mView.findViewById(R.id.et_dialog_userName);       //要用对应布局的view对象去findViewById获取控件对象
                et_dialog_phone = (EditText) mView.findViewById(R.id.et_dialog_userPhone);
                et_dialog_name.setText(((TextView) view.findViewById(R.id.user_name)).getText());   //获取并显示原来的姓名
                et_dialog_phone.setText(((TextView) view.findViewById(R.id.user_phone)).getText());       //获取并显示原来的电话
                new AlertDialog.Builder(StudentActivity.this)
                        .setTitle("修改信息")
                        .setMessage("您是否要修改该用户数据?")
                        .setView(mView)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                String name = et_dialog_name.getText().toString().trim();  //获取修改后的名字
                                String phoneNumber = et_dialog_phone.getText().toString().trim();  //获取修改后的手机号
                                if (name.equals("") || phoneNumber.equals("")) {
                                    Toast.makeText(StudentActivity.this, "不能为空呀，请重新填写", Toast.LENGTH_LONG).show();
                                } else {
                                    updateData(position);
                                }
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });


        //长按删除item
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int position, long l) {
                Cursor cursor = simpleCursorAdapter.getCursor();
                cursor.moveToPosition(position);
                String itemID = cursor.getString(cursor.getColumnIndex("userID"));
                String itemName = cursor.getString(cursor.getColumnIndex("realName_u"));
                new AlertDialog.Builder(StudentActivity.this)
                        .setTitle("提示")
                        .setMessage("是否删除该用户：\n" + itemID + "  " + itemName)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                deleteData(position);
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
                return true;
            }
        });
    }


    private void initView() {
        listView = (ListView) findViewById(R.id.studentListview);
        btn_insert = (Button) findViewById(R.id.btn_insert);
        btn_search = (Button) findViewById(R.id.btn_search);
        et_ID = (EditText) findViewById(R.id.et_studentID);
        et_name = (EditText) findViewById(R.id.et_studentName);
        et_phone = (EditText) findViewById(R.id.et_studentPhone);
        et_search = (EditText) findViewById(R.id.et_searchStudent);

    }

    private void initEvent() {
        btn_insert.setOnClickListener(this);
        btn_search.setOnClickListener(this);

        openHelper = new DBOpenHelper(this);
        mDbWriter = openHelper.getWritableDatabase();
        mDbReader = openHelper.getReadableDatabase();

        simpleCursorAdapter = new SimpleCursorAdapter(StudentActivity.this, R.layout.user_item, null,
                new String[]{"userID", "realName_u", "phoneNumber_u"}, new int[]{R.id.user_id, R.id.user_name, R.id.user_phone}, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

        listView.setAdapter(simpleCursorAdapter);     //给ListView设置适配器
        refreshListview();      //自定义的方法，用于当数据列表改变时刷新ListView

    }

    //刷新数据列表
    public void refreshListview() {
        Cursor cursor = mDbWriter.query(DBOpenHelper.USER_INFO, null, "identity=?", new String[]{"1"}, null, null, "userID");
        simpleCursorAdapter.changeCursor(cursor);
    }

    //添加用户
    public void insertData() {
        ContentValues cv = new ContentValues();
        cv.put("userID", et_ID.getText().toString().trim());
        cv.put("realName_u", et_name.getText().toString().trim());
        cv.put("phoneNumber_u", et_phone.getText().toString().trim());
        cv.put("identity", "1");  //代表学生身份
        String ID = et_ID.getText().toString().trim();  //获取输入的ID
        String realName = et_name.getText().toString().trim();  //获取输入的姓名
        String phone = et_phone.getText().toString().trim();  //获取输入的手机号
        if (ID.equals("") || realName.equals("")) {  //学生的手机号可以为空
            Toast.makeText(StudentActivity.this, "ID和姓名不能为空呀，请重新填写", Toast.LENGTH_SHORT).show();
        } else {
            Cursor cursor1 = mDbReader.query(DBOpenHelper.USER_INFO, null, "userID=?", new String[]{ID}, null, null, null);
            if (cursor1.getCount() > 0) {
                Toast.makeText(StudentActivity.this, "该用户ID已经名花有主啦，请重新填写~", Toast.LENGTH_LONG).show();
            } else {
                if (!phone.isEmpty()) {
                    if (PhoneNumberUtils.checkTel(phone)) { //利用正则表达式检验手机号
                        Cursor cursor = mDbReader.query(DBOpenHelper.USER_INFO, null, "phoneNumber_u=?", new String[]{phone}, null, null, null);
                        if (cursor.getCount() > 0) {
                            Toast.makeText(StudentActivity.this, "该手机号已经名花有主啦，请重新填写~", Toast.LENGTH_LONG).show();
                            et_phone.setText("");
                        } else {
                            ContentValues scontentValues = new ContentValues();
                            scontentValues.put("studentID", et_ID.getText().toString().trim());
                            scontentValues.put("userName_s", "暂无");
                            scontentValues.put("realName_s", et_name.getText().toString().trim());
                            scontentValues.put("phoneNumber_s", et_phone.getText().toString().trim());
                            scontentValues.put("password_s", "暂无");
                            mDbWriter.insert(DBOpenHelper.USER_INFO, null, cv);
                            mDbWriter.insert(DBOpenHelper.STUDENT_INFO, null, scontentValues); //同时将信息插入student表
                            refreshListview();
                            Toast.makeText(StudentActivity.this, "添加成功~", Toast.LENGTH_LONG).show();
                            et_ID.setText("");   //插入成功清空输入框
                            et_name.setText("");
                            et_phone.setText("");
                        }
                    } else {
                        Toast.makeText(StudentActivity.this, "请填写规范的手机号！", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    ContentValues scontentValues = new ContentValues();
                    scontentValues.put("studentID", et_ID.getText().toString().trim());
                    scontentValues.put("userName_s", "暂无");
                    scontentValues.put("realName_s", et_name.getText().toString().trim());
                    scontentValues.put("phoneNumber_s", "手机号暂无");
                    scontentValues.put("password_s", "暂无");
                    cv.put("phoneNumber_u", "手机号暂无");
                    mDbWriter.insert(DBOpenHelper.USER_INFO, null, cv);
                    mDbWriter.insert(DBOpenHelper.STUDENT_INFO, null, scontentValues); //同时将信息插入student表
                    Toast.makeText(StudentActivity.this, "添加成功~", Toast.LENGTH_LONG).show();
                    refreshListview();
                    et_ID.setText("");   //插入成功清空输入框
                    et_name.setText("");
                    et_phone.setText("");
                }
            }
        }
    }

    //删除用户
    public void deleteData(int position) {
        Cursor cursor = simpleCursorAdapter.getCursor();
        cursor.moveToPosition(position);
        String itemID = cursor.getString(cursor.getColumnIndex("userID"));
        mDbWriter.delete(DBOpenHelper.USER_INFO, "userID=?", new String[]{itemID});
        mDbWriter.delete(DBOpenHelper.STUDENT_INFO, "studentID=?", new String[]{itemID});  //同时删除student表中的相关数据
        refreshListview();
    }

    //修改用户
    public void updateData(int position) {
        Cursor cursor = simpleCursorAdapter.getCursor();
        cursor.moveToPosition(position);
        String itemID = cursor.getString(cursor.getColumnIndex("userID"));
        String name = et_dialog_name.getText().toString().trim();
        String phone = et_dialog_phone.getText().toString().trim();
        if (PhoneNumberUtils.checkTel(phone)) { //利用正则表达式检验手机号
            Cursor cursor2 = mDbReader.query(DBOpenHelper.USER_INFO, null, "phoneNumber_u=?", new String[]{phone}, null, null, null);
            if (cursor2.getCount() > 0) {
                Toast.makeText(StudentActivity.this, "该手机号已经名花有主啦，请重新填写~", Toast.LENGTH_LONG).show();
            } else {
                ContentValues mContentValues = new ContentValues();
                mContentValues.put("realName_u", name);
                mContentValues.put("phoneNumber_u", phone);

                ContentValues sContentValues = new ContentValues();
                sContentValues.put("realName_s", name);
                sContentValues.put("phoneNumber_s", phone);
                mDbWriter.update(DBOpenHelper.USER_INFO, mContentValues, "userID=?", new String[]{itemID});
                mDbWriter.update(DBOpenHelper.STUDENT_INFO, sContentValues, "studentID=?", new String[]{itemID});  //同时修改student表的数据
                refreshListview();
            }
        } else {
            Toast.makeText(StudentActivity.this, "请填写规范的手机号！", Toast.LENGTH_SHORT).show();
        }

    }

    //查询用户
    public void searchData() {
        String input = et_search.getText().toString().trim();
        Cursor cursor = mDbReader.query(DBOpenHelper.USER_INFO, null, "identity=1 and realName_u=?", new String[]{input}, null, null, null);
        if (cursor.getCount() > 0) {
            list.clear();        //清空List
            while (cursor.moveToNext()) {     //游标总是在查询到的上一行
                Map<String, String> map = new HashMap<>();
                String searchID = cursor.getString(cursor.getColumnIndex("userID"));
                String searchPhone = cursor.getString(cursor.getColumnIndex("phoneNumber_u"));
                map.put("tv1", "ID：" + searchID);
                map.put("tv2", "姓名：" + input);
                map.put("tv3", "电话：" + searchPhone);
//                Toast.makeText(StudentActivity.this, "有的", Toast.LENGTH_SHORT).show();
                list.add(map);
                flag = 1;
            }
            cursor.close();
        } else {
            list.clear();  //清空List
            Map<String, String> map = new HashMap<>();
            map.put("null", "查询结果为空，请确认您输入的名字是否正确");
//            Toast.makeText(StudentActivity.this, "没有", Toast.LENGTH_SHORT).show();
            list.add(map);
            flag = 0;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            //点击添加按钮
            case R.id.btn_insert:
                insertData();
                break;
            //点击查询按钮
            case R.id.btn_search:
                searchData();
                if (flag == 1) {
                    new AlertDialog.Builder(StudentActivity.this)
                            .setTitle("查询结果")
                            .setAdapter(new SimpleAdapter(StudentActivity.this, list, R.layout.dialog_tv_layout, new String[]{"tv1", "tv2", "tv3"}, new int[]{R.id.tv1_dialog, R.id.tv2_dialog, R.id.tv3_dialog}), null)
                            .setPositiveButton("确定", null)
                            .show();
                } else {
                    android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(StudentActivity.this);
                    final android.app.AlertDialog dialog = builder.create();
                    final View dialogView = View.inflate(StudentActivity.this, R.layout.custom_dialog_layout, null);
                    //设置对话框布局
                    dialog.setView(dialogView);
                    dialog.show();
                    dialog.getWindow().setBackgroundDrawable(null);
                    final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_ok);
                    btnCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                        }
                    });
                }
                break;

        }
    }
}
