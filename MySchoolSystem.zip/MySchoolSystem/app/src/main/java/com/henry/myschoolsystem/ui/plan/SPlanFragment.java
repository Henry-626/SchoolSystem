package com.henry.myschoolsystem.ui.plan;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cursoradapter.widget.CursorAdapter;
import androidx.cursoradapter.widget.SimpleCursorAdapter;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.ui.admin.StudentActivity;
import com.henry.myschoolsystem.ui.login.DBOpenHelper;
import com.henry.myschoolsystem.utils.CurrentUser;
import com.henry.myschoolsystem.utils.PhoneNumberUtils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class SPlanFragment extends Fragment {

    private List<Map<String, String>> list = new ArrayList<>();
    private ListView listView1, listView2;
    private EditText et_time, et_content, et_dialog_time, et_dialog_content;
    private Button btn_insert;
    private SimpleCursorAdapter simpleCursorAdapter1, simpleCursorAdapter2;
    private SQLiteDatabase mDbWriter;
    private SQLiteDatabase mDbReader;
    private DBOpenHelper openHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_splan, container, false);

        listView1 = (ListView) root.findViewById(R.id.planListView);
        listView2 = (ListView) root.findViewById(R.id.planFinishedListView);
        et_time = root.findViewById(R.id.sPlan_time);
        et_content = root.findViewById(R.id.sPlan_content);
        btn_insert = root.findViewById(R.id.btn_add_sPlan);
        initEvent();

        //单击修改item
        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, final View view, final int position, long l) {
                View mView = View.inflate(getActivity(), R.layout.dialog_et3_layout, null);       //将放置了两个EditText的布局dialog_et3_layout渲染成view对象
                et_dialog_time = (EditText) mView.findViewById(R.id.et_dialog_time);       //要用对应布局的view对象去findViewById获取控件对象
                et_dialog_content = (EditText) mView.findViewById(R.id.et_dialog_content);
                et_dialog_time.setText(((TextView) view.findViewById(R.id.plan_ddl)).getText());   //获取并显示原来的时间
                et_dialog_content.setText(((TextView) view.findViewById(R.id.plan_content1)).getText());       //获取并显示原来的内容
                new AlertDialog.Builder(getActivity())
                        .setTitle("修改信息")
                        .setMessage("您是否要修改该计划?")
                        .setView(mView)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                String time = et_dialog_time.getText().toString().trim();  //获取修改后的日期
                                String content = et_dialog_content.getText().toString().trim();  //获取修改后的内容
                                if (time.equals("") || content.equals("")) {
                                    Toast.makeText(getActivity(), "不能为空呀，请重新填写", Toast.LENGTH_LONG).show();
                                } else {
                                    updateData(position);
                                }
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
            }
        });


        //长按完成计划
        listView1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int position, long l) {
                Cursor cursor = simpleCursorAdapter1.getCursor();
                cursor.moveToPosition(position);
                String itemContent = cursor.getString(cursor.getColumnIndex("planContent_s"));
                new AlertDialog.Builder(getActivity())
                        .setTitle("提示")
                        .setMessage("该计划已完成？\n" + ">" + itemContent)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                finish(position);
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
                return true;
            }
        });

        //长按删除已完成计划
        listView2.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, final int position, long l) {
                Cursor cursor = simpleCursorAdapter2.getCursor();
                cursor.moveToPosition(position);
                String itemContent = cursor.getString(cursor.getColumnIndex("finishedContent_s"));
                new AlertDialog.Builder(getActivity())
                        .setTitle("提示")
                        .setMessage("是否删除该已完成计划：\n" + itemContent )
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                deleteData(position);
                            }
                        })
                        .setNegativeButton("取消", null)
                        .show();
                return true;
            }
        });

        btn_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
            }
        });
        return root;
    }

    private void initEvent() {

        openHelper = new DBOpenHelper(getActivity());
        mDbWriter = openHelper.getWritableDatabase();
        mDbReader = openHelper.getReadableDatabase();

        simpleCursorAdapter1 = new SimpleCursorAdapter(getActivity(), R.layout.plan_item, null,
                new String[]{"deadline_s", "planContent_s"}, new int[]{R.id.plan_ddl, R.id.plan_content1}, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);
        simpleCursorAdapter2 = new SimpleCursorAdapter(getActivity(), R.layout.plan_finished_item, null,
                new String[]{"finishedTime_s", "finishedContent_s"}, new int[]{R.id.plan_finished_time, R.id.plan_content2}, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

        listView1.setAdapter(simpleCursorAdapter1);     //给ListView设置适配器
        listView2.setAdapter(simpleCursorAdapter2);     //给ListView设置适配器
        refreshListview();      //自定义的方法，用于当数据列表改变时刷新ListView

    }

    //刷新数据列表
    public void refreshListview() {
        Cursor cursor1 = mDbWriter.query(DBOpenHelper.SPLAN, null, null, null, null, null, null);
        simpleCursorAdapter1.changeCursor(cursor1);
        Cursor cursor2 = mDbWriter.query(DBOpenHelper.SPLANFINISHED, null, null, null, null, null, null);
        simpleCursorAdapter2.changeCursor(cursor2);
    }

    //添加计划
    public void insertData() {
        ContentValues cv = new ContentValues();
        cv.put("deadline_s", et_time.getText().toString().trim());
        cv.put("planContent_s", et_content.getText().toString().trim());
        cv.put("studentID_p", CurrentUser.getuserID());
        String time = et_time.getText().toString().trim();  //获取输入的ddl
        String content = et_content.getText().toString().trim();  //获取输入的内容
        if (time.equals("") || content.equals("")) {
            Toast.makeText(getActivity(), "要填写完整吖，请重新填写", Toast.LENGTH_SHORT).show();
        } else {
            mDbWriter.insert(DBOpenHelper.SPLAN, null, cv);
            refreshListview();
            Toast.makeText(getActivity(), "添加成功~", Toast.LENGTH_LONG).show();
            et_time.setText("");   //插入成功清空输入框
            et_content.setText("");
        }
    }

    //完成计划
    public void finish(int position) {
        Cursor cursor = simpleCursorAdapter1.getCursor();
        cursor.moveToPosition(position);
        String itemID = cursor.getString(cursor.getColumnIndex("_id"));
        String content = cursor.getString(cursor.getColumnIndex("planContent_s"));
        mDbWriter.delete(DBOpenHelper.SPLAN, "_id=?", new String[]{itemID});

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm");// HH:mm
        //获取当前时间
        Date date = new Date(System.currentTimeMillis());
        ContentValues cv = new ContentValues();
        cv.put("finishedTime_s", simpleDateFormat.format(date));  //完成的时间
        cv.put("finishedContent_s", content);
        cv.put("studentID_pf", CurrentUser.getuserID());
        mDbWriter.insert(DBOpenHelper.SPLANFINISHED, null, cv);
        refreshListview();
    }

    //删除计划
    public void deleteData(int position) {
        Cursor cursor = simpleCursorAdapter2.getCursor();
        cursor.moveToPosition(position);
        String itemID = cursor.getString(cursor.getColumnIndex("_id"));
        mDbWriter.delete(DBOpenHelper.SPLANFINISHED, "_id=?", new String[]{itemID});
        refreshListview();
    }

    //修改计划
    public void updateData(int position) {
        Cursor cursor = simpleCursorAdapter1.getCursor();
        cursor.moveToPosition(position);
        String itemID = cursor.getString(cursor.getColumnIndex("_id"));
        String time = et_dialog_time.getText().toString().trim();
        String content = et_dialog_content.getText().toString().trim();
        ContentValues cv = new ContentValues();
        cv.put("deadline_s", time);
        cv.put("planContent_s", content);
        mDbWriter.update(DBOpenHelper.SPLAN, cv, "_id=?", new String[]{itemID});
        refreshListview();
    }

}
