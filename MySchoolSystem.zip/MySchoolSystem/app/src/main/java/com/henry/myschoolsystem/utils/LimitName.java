package com.henry.myschoolsystem.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LimitName {
    public static boolean limitName(String name) {
        Pattern p = Pattern.compile("^[A-Za-z0-9\\-]+$");
        Matcher matcher = p.matcher(name);
        return matcher.matches();
    }
}
