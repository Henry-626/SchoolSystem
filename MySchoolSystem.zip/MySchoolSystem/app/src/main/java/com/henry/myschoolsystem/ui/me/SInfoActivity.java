package com.henry.myschoolsystem.ui.me;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.henry.myschoolsystem.InitActivity;
import com.henry.myschoolsystem.R;
import com.henry.myschoolsystem.bean.ClassBean;
import com.henry.myschoolsystem.bean.StudentBean;
import com.henry.myschoolsystem.bean.TeacherBean;
import com.henry.myschoolsystem.ui.admin.AdminActivity;
import com.henry.myschoolsystem.ui.admin.ClassActivity;
import com.henry.myschoolsystem.ui.admin.StudentActivity;
import com.henry.myschoolsystem.ui.admin.Teacher2Activity;
import com.henry.myschoolsystem.ui.admin.TeacherActivity;
import com.henry.myschoolsystem.ui.login.SRegisterActivity;
import com.henry.myschoolsystem.ui.login.TLoginActivity;
import com.henry.myschoolsystem.ui.login.TRegisterActivity;
import com.henry.myschoolsystem.utils.CurrentUser;
import com.henry.myschoolsystem.utils.DBUtils;
import com.henry.myschoolsystem.utils.PhoneNumberUtils;

import cn.smssdk.SMSSDK;

public class SInfoActivity extends AppCompatActivity {

    private TextView tv_id, tv_userName, tv_realName, tv_nickName, tv_sex, tv_class, tv_qq, tv_wechat, tv_motto, tv_phoneNumber;
    private ImageButton ib_nickName, ib_sex, ib_class, ib_qq, ib_wechat, ib_motto, ib_phoneNumber;
    private EditText et_content, et_code; //一个是通用的输入内容的，一个是在加班级时输入验证码的

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sinfo);

        tv_id = findViewById(R.id.sInfo_ID);
        tv_userName = findViewById(R.id.sInfo_username);
        tv_realName = findViewById(R.id.sInfo_realName);
        tv_nickName = findViewById(R.id.sInfo_nickname);
        tv_sex = findViewById(R.id.sInfo_sex);
        tv_class = findViewById(R.id.sInfo_class);
        tv_qq = findViewById(R.id.sInfo_qq);
        tv_wechat = findViewById(R.id.sInfo_wechat);
        tv_phoneNumber = findViewById(R.id.sInfo_phone);
        tv_motto = findViewById(R.id.sInfo_motto);

        ib_nickName = findViewById(R.id.sEditButton1);
        ib_sex = findViewById(R.id.sEditButton2);
        ib_class = findViewById(R.id.sEditButton3);
        ib_qq = findViewById(R.id.sEditButton4);
        ib_wechat = findViewById(R.id.sEditButton5);
        ib_phoneNumber = findViewById(R.id.sEditButton6);
        ib_motto = findViewById(R.id.sEditButton7);

        //设置默认显示的值
        tv_id.setText(CurrentUser.getuserID());
        tv_userName.setText(CurrentUser.getUserName());
        tv_realName.setText(CurrentUser.getRealName());

        StudentBean studentBean = getStudentDataByStudentNum(CurrentUser.getuserID());
        tv_nickName.setText(studentBean.nickName);
        tv_sex.setText(studentBean.sex);
        tv_qq.setText(studentBean.qq);
        tv_wechat.setText(studentBean.wechat);
        tv_phoneNumber.setText(studentBean.phoneNumber);
        tv_motto.setText(studentBean.motto);

        ClassBean classBean = getClassDataByStudentID(studentBean.ID);
        if (classBean != null) {
            tv_class.setText(classBean.year + classBean.className);
        } else {
            tv_class.setText("暂未绑定班级");
        }

        //设置监听
        ib_nickName.setOnClickListener(new EditNickName());    //昵称编辑
        ib_sex.setOnClickListener(new EditSex());    //性别编辑
        ib_class.setOnClickListener(new EditClass());    //班级编辑
        ib_qq.setOnClickListener(new EditQQ());    //qq编辑
        ib_wechat.setOnClickListener(new EditWechat());    //微信编辑
        ib_phoneNumber.setOnClickListener(new EditPhoneNumber());    //手机号编辑
        ib_motto.setOnClickListener(new EditMotto());    //签名编辑

    }

    private class EditNickName implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(SInfoActivity.this);
            final android.app.AlertDialog dialog = builder.create();
            final View dialogView = View.inflate(SInfoActivity.this, R.layout.dialog_et0_layout, null);
            //设置对话框布局
            dialog.setView(dialogView);
            dialog.show();
            dialog.getWindow().setBackgroundDrawable(null);
            final Button btnCommit = (Button) dialogView.findViewById(R.id.btn_info_commit);
            final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_info_cancel);
            btnCommit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    et_content = (EditText) dialogView.findViewById(R.id.et_myInfo);
                    String content = et_content.getText().toString().trim();
                    if (content.equals("")) {
                        Toast.makeText(SInfoActivity.this, "信息不能为空呀，请重新填写", Toast.LENGTH_SHORT).show();
                    } else {
                        updateStudent("nickName_s", et_content.getText().toString().trim(), CurrentUser.getuserID());
                        CurrentUser.setNickName(content); //更新全局变量
                        Toast.makeText(SInfoActivity.this, "修改成功！", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        tv_nickName.setText(content);
                    }
                }
            });
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }
    }

    private class EditSex implements View.OnClickListener {
        @Override
        public void onClick(View view) {

            final String[] items = new String[]{"男", "女", "保密"};
            final String[] select = new String[1];
            AlertDialog.Builder builder = new AlertDialog.Builder(SInfoActivity.this);
            builder.setTitle("性别选择");
            builder.setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Toast.makeText(SInfoActivity.this, "您选择了：" + items[which], Toast.LENGTH_SHORT).show();
                    select[0] = items[which];
                }
            });
            builder.setPositiveButton("确认", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    updateStudent("sex_s", select[0], CurrentUser.getuserID());
                    tv_sex.setText(select[0]);
                    dialog.dismiss();
                }
            });
            builder.create().show();
        }
    }

    private class EditClass implements View.OnClickListener {
        @Override
        public void onClick(View view) {
//            Toast.makeText(SInfoActivity.this, "我被点击啦！", Toast.LENGTH_SHORT).show();
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(SInfoActivity.this);
            final android.app.AlertDialog dialog = builder.create();
            final View dialogView = View.inflate(SInfoActivity.this, R.layout.dialog_et_class_layout, null);
            //设置对话框布局
            dialog.setView(dialogView);
            dialog.show();
            dialog.getWindow().setBackgroundDrawable(null);
            final Button btnCommit = (Button) dialogView.findViewById(R.id.btn_info_commit_class);
            final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_info_cancel_class);
            btnCommit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    et_content = (EditText) dialogView.findViewById(R.id.et_info_class);
                    et_code = (EditText) dialogView.findViewById(R.id.et_info_classCode);
                    String content = et_content.getText().toString().trim();
                    String code = et_code.getText().toString().trim();
                    if (content.equals("") || code.equals("")) {
                        Toast.makeText(SInfoActivity.this, "信息不能为空呀，请重新填写", Toast.LENGTH_SHORT).show();
                    } else {
                        ClassBean classBean = null;
                        classBean = getClassDataByStudentID(CurrentUser.getuserID());
                        if (classBean == null) {
                            ClassBean classBean1 = getClassDataByClassID(content);
                            if (classBean1 == null) {
                                Toast.makeText(SInfoActivity.this, "该班级不存在，请重新输入！", Toast.LENGTH_SHORT).show();
                            } else {
                                if (code.equals(classBean1.code)) {
//                                    classBean.classID = content;
//                                    classBean.year = classBean1.year;
//                                    classBean.teacherID = classBean1.teacherID;
//                                    classBean.teacherName = classBean1.teacherName;
//                                    classBean.studentID = CurrentUser.getuserID();
//                                    classBean.className = classBean1.className;
//                                    classBean.code = code;
//                                    addStudent(classBean);
                                    Toast.makeText(SInfoActivity.this, "绑定成功！", Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                    tv_class.setText(content);
                                } else {
                                    Toast.makeText(SInfoActivity.this, "输入的验证码不正确，请重新输入！", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {
                            ClassBean classBean2 = getClassDataByClassID(content);
                            if (classBean2 == null) {
                                Toast.makeText(SInfoActivity.this, "该班级不存在，请重新输入！", Toast.LENGTH_SHORT).show();
                            } else {
                                if (code.equals(classBean2.code)) {
                                    classBean.classID = content;
                                    classBean.year = classBean2.year;
                                    classBean.teacherID = classBean2.teacherID;
                                    classBean.teacherName = classBean2.teacherName;
                                    classBean.className = classBean2.className;
                                    classBean.code = code;
                                    updateClass(CurrentUser.getuserID(), classBean);
                                    Toast.makeText(SInfoActivity.this, "修改成功！", Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                    tv_class.setText(content);
                                }
                            }
                        }
                    }
                }
            });
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }
    }

    private class EditQQ implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(SInfoActivity.this);
            final android.app.AlertDialog dialog = builder.create();
            final View dialogView = View.inflate(SInfoActivity.this, R.layout.dialog_et00_layout, null);
            //设置对话框布局
            dialog.setView(dialogView);
            dialog.show();
            dialog.getWindow().setBackgroundDrawable(null);
            final Button btnCommit = (Button) dialogView.findViewById(R.id.btn_info_commit_qq);
            final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_info_cancel_qq);
            btnCommit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    et_content = (EditText) dialogView.findViewById(R.id.et_myInfo_qq);
                    String content = et_content.getText().toString().trim();
                    if (content.equals("")) {
                        Toast.makeText(SInfoActivity.this, "信息不能为空呀，请重新填写", Toast.LENGTH_SHORT).show();
                    } else {
                        updateStudent("qq_s", et_content.getText().toString().trim(), CurrentUser.getuserID());
                        Toast.makeText(SInfoActivity.this, "修改成功！", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        tv_qq.setText(content);
                    }
                }
            });
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }
    }

    private class EditWechat implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(SInfoActivity.this);
            final android.app.AlertDialog dialog = builder.create();
            final View dialogView = View.inflate(SInfoActivity.this, R.layout.dialog_et0_layout, null);
            //设置对话框布局
            dialog.setView(dialogView);
            dialog.show();
            dialog.getWindow().setBackgroundDrawable(null);
            final Button btnCommit = (Button) dialogView.findViewById(R.id.btn_info_commit);
            final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_info_cancel);
            btnCommit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    et_content = (EditText) dialogView.findViewById(R.id.et_myInfo);
                    String content = et_content.getText().toString().trim();
                    if (content.equals("")) {
                        Toast.makeText(SInfoActivity.this, "信息不能为空呀，请重新填写", Toast.LENGTH_SHORT).show();
                    } else {
                        updateStudent("wechat_s", et_content.getText().toString().trim(), CurrentUser.getuserID());
                        Toast.makeText(SInfoActivity.this, "修改成功！", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        tv_wechat.setText(content);
                    }
                }
            });
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }
    }

    private class EditPhoneNumber implements View.OnClickListener {
        @Override
        public void onClick(View view) {
//            Toast.makeText(SInfoActivity.this, "我被点击啦！", Toast.LENGTH_SHORT).show();
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(SInfoActivity.this);
            final android.app.AlertDialog dialog = builder.create();
            final View dialogView = View.inflate(SInfoActivity.this, R.layout.dialog_et00_layout, null);
            //设置对话框布局
            dialog.setView(dialogView);
            dialog.show();
            dialog.getWindow().setBackgroundDrawable(null);
            final Button btnCommit = (Button) dialogView.findViewById(R.id.btn_info_commit_qq);
            final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_info_cancel_qq);
            btnCommit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    et_content = (EditText) dialogView.findViewById(R.id.et_myInfo_qq);
                    String content = et_content.getText().toString().trim();
                    if (content.equals("")) {
                        Toast.makeText(SInfoActivity.this, "信息不能为空呀，请重新填写", Toast.LENGTH_SHORT).show();
                    } else {
                        if (PhoneNumberUtils.checkTel(content)) { //利用正则表达式检验手机号
                            TeacherBean bean = null;
                            StudentBean bean2 = null;
                            //检查数据库中该手机号是否已经被绑定
                            bean = getTeacherDataByPhoneNum(content);
                            bean2 = getStudentDataByPhoneNum(content);
                            if (bean == null && bean2 == null) {
                                Toast.makeText(SInfoActivity.this, "该手机号不可用，需要先以管理员身份添加", Toast.LENGTH_SHORT).show();
                            } else {
                                if (bean != null) {
                                    if (!bean.userName.equals("暂无")) {
                                        Toast.makeText(SInfoActivity.this, "该手机号已绑定过用户！", Toast.LENGTH_SHORT).show();
                                    } else {
                                        if (bean2 != null) {
                                            if (!bean2.userName.equals("暂无")) {
                                                Toast.makeText(SInfoActivity.this, "该手机号已绑定过用户！", Toast.LENGTH_SHORT).show();
                                            } else {
                                                // 获取验证码
                                                SMSSDK.getVerificationCode("86", content);
                                            }
                                        } else {   //bean2 = null, 则肯定未绑定
                                            updateStudent("phoneNumber_s", et_content.getText().toString().trim(), CurrentUser.getuserID());
                                            Toast.makeText(SInfoActivity.this, "修改成功！", Toast.LENGTH_SHORT).show();
                                            dialog.dismiss();
                                            tv_phoneNumber.setText(content);
                                        }
                                    }
                                } else {
                                    if (!bean2.userName.equals("暂无")) {
                                        Toast.makeText(SInfoActivity.this, "该手机号已绑定过用户！", Toast.LENGTH_SHORT).show();
                                    } else {
                                        updateStudent("phoneNumber_s", et_content.getText().toString().trim(), CurrentUser.getuserID());
                                        Toast.makeText(SInfoActivity.this, "修改成功！", Toast.LENGTH_SHORT).show();
                                        dialog.dismiss();
                                        tv_phoneNumber.setText(content);
                                    }
                                }
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "请输入有效的手机号", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }
    }

    private class EditMotto implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(SInfoActivity.this);
            final android.app.AlertDialog dialog = builder.create();
            final View dialogView = View.inflate(SInfoActivity.this, R.layout.dialog_et0_layout, null);
            //设置对话框布局
            dialog.setView(dialogView);
            dialog.show();
            dialog.getWindow().setBackgroundDrawable(null);
            final Button btnCommit = (Button) dialogView.findViewById(R.id.btn_info_commit);
            final Button btnCancel = (Button) dialogView.findViewById(R.id.btn_info_cancel);
            btnCommit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    et_content = (EditText) dialogView.findViewById(R.id.et_myInfo);
                    String content = et_content.getText().toString().trim();
                    if (content.equals("")) {
                        Toast.makeText(SInfoActivity.this, "信息不能为空呀，请重新填写", Toast.LENGTH_SHORT).show();
                    } else {
                        updateStudent("motto_s", et_content.getText().toString().trim(), CurrentUser.getuserID());
                        Toast.makeText(SInfoActivity.this, "修改成功！", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                        tv_motto.setText(content);
                    }
                }
            });
            btnCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialog.dismiss();
                }
            });
        }
    }

    //更新信息
    private void updateStudent(String key, String value, String id) {
        DBUtils.getInstance(this).updateStudentInfoByID(key, value, id);
    }

    //更新班级信息
    private void updateClass(String id, ClassBean classBean) {
        DBUtils.getInstance(this).updateClassInfoAll(id, classBean);
    }

    //通过学生ID获取相应班级信息
    private ClassBean getClassDataByStudentID(String id) {
        ClassBean bean = DBUtils.getInstance(this).getClassInfoByStudentID(id);
        return bean;
    }

    //通过输入的班级ID获取相应班级信息
    private ClassBean getClassDataByClassID(String id) {
        ClassBean bean = DBUtils.getInstance(this).getClassInfoByID(id);
        return bean;
    }

    //给相应班级添加学生记录
    private void addStudent(ClassBean bean) {
        DBUtils.getInstance(this).saveStudentInfo(bean);
    }

    private StudentBean getStudentDataByStudentNum(String id) {
        StudentBean bean = DBUtils.getInstance(this).getStudentInfoByID(id);
        return bean;
    }

    //需要检查填入的手机号是否与学生用户绑定
    private StudentBean getStudentDataByPhoneNum(String phone) {
        StudentBean bean = DBUtils.getInstance(this).getStudentInfoByPhoneNum(phone);
        return bean;
    }

    //还需要检查填入的手机号是否在教师端被绑定
    private TeacherBean getTeacherDataByPhoneNum(String phone) {
        TeacherBean bean = DBUtils.getInstance(this).getTeacherInfoByPhoneNum(phone);
        return bean;
    }
}
